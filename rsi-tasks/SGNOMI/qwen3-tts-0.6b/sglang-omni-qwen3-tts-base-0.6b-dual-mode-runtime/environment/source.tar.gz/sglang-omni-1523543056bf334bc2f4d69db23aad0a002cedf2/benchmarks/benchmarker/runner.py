# SPDX-License-Identifier: Apache-2.0
"""BenchmarkRunner: warmup + concurrent dispatch with semaphore and rate limiting."""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any, Callable, Coroutine

import aiohttp
import numpy as np
from tqdm.asyncio import tqdm

from benchmarks.benchmarker.data import RequestResult

logger = logging.getLogger(__name__)

SendFn = Callable[[aiohttp.ClientSession, Any], Coroutine[Any, Any, RequestResult]]


def resolve_warmup(warmup: int | None, max_concurrency: int) -> int:
    # note (luojiaxuan): warmup=None means match the configured concurrency, so
    # the timed cohort is not the first to absorb concurrency-shaped cold work.
    # An explicit count always wins, including 0 to disable warmup entirely.
    if warmup is not None:
        return warmup
    return max_concurrency if max_concurrency > 0 else 1


@dataclass
class RunConfig:
    max_concurrency: int = 1
    request_rate: float = float("inf")
    warmup: int | None = None
    disable_tqdm: bool = False
    timeout_s: int = 300
    # note (luojiaxuan): seeds the Poisson inter-arrival draws so every run
    # offers the same arrival sequence; None draws a fresh sequence per run.
    arrival_seed: int | None = None

    @property
    def effective_warmup(self) -> int:
        return resolve_warmup(self.warmup, self.max_concurrency)


class BenchmarkRunner:
    """Support concurrent requests sending in a single benchmark run.

    Note (chenyang):
    max_concurrency is default to 1, thus all the requests are runs sequentially.

    TODO (chenyang):
    Current concurrency implementation of models are not fully supported.
    https://github.com/sgl-project/sglang-omni/issues/229
    https://github.com/sgl-project/sglang-omni/issues/228
    """

    def __init__(self, config: RunConfig) -> None:
        self.config = config
        self.wall_clock_s: float = 0.0

    async def run(self, samples: list, send_fn: SendFn) -> list[RequestResult]:
        timeout = aiohttp.ClientTimeout(total=self.config.timeout_s)
        # note (guozhihao): Closed-loop runs are bounded by max_concurrency.
        # Open-loop (max_concurrency=0) must not inherit aiohttp's default
        # 100-conn cap, or sustained overshoot silently queues on the client.
        connector = (
            aiohttp.TCPConnector(limit=0) if not self.config.max_concurrency else None
        )
        async with aiohttp.ClientSession(
            timeout=timeout, connector=connector
        ) as session:
            if self.config.effective_warmup > 0:
                await self._warmup(session, samples, send_fn)

            logger.info(
                "Benchmarking %d requests (max_concurrency=%s)...",
                len(samples),
                self.config.max_concurrency,
            )
            t0 = time.perf_counter()
            results = await self._dispatch(session, samples, send_fn)
            self.wall_clock_s = time.perf_counter() - t0
        return results

    async def _warmup(
        self,
        session: aiohttp.ClientSession,
        samples: list,
        send_fn: SendFn,
    ) -> None:
        count = self.config.effective_warmup if samples else 0
        logger.info("Warmup (%d requests)...", count)
        semaphore = (
            asyncio.Semaphore(self.config.max_concurrency)
            if self.config.max_concurrency
            else None
        )

        async def _limited(sample: Any) -> RequestResult:
            if semaphore is None:
                return await send_fn(session, sample)
            async with semaphore:
                return await send_fn(session, sample)

        # note (luojiaxuan): The measured cohort reuses this same sample list,
        # so warming distinct samples would pre-fill per-sample server caches,
        # such as the MOSS-TTS reference-audio cache, for requests that are
        # about to be timed. Repeat one sample to get the concurrency shape
        # without widening that bias as concurrency grows.
        results = await asyncio.gather(*(_limited(samples[0]) for _ in range(count)))
        for i, result in enumerate(results):
            status = "ok" if result.is_success else result.error
            logger.info("  warmup %d/%d: %s", i + 1, count, status)
            if not result.is_success:
                raise ValueError(
                    "Warmup failed - Please make sure benchmark arguments are "
                    f"correctly specified. Error: {result.error}"
                )

    async def _dispatch(
        self,
        session: aiohttp.ClientSession,
        samples: list,
        send_fn: SendFn,
    ) -> list[RequestResult]:
        semaphore = (
            asyncio.Semaphore(self.config.max_concurrency)
            if self.config.max_concurrency
            else None
        )
        pbar = tqdm(total=len(samples), disable=self.config.disable_tqdm)
        loop = asyncio.get_running_loop()
        open_loop = self.config.request_rate != float("inf")
        # note (luojiaxuan): arrivals are planned as offsets from the dispatch
        # start and each request waits for its own offset, so one late send
        # does not push every later arrival back.
        planned_offsets = (
            np.cumsum(
                np.random.default_rng(self.config.arrival_seed).exponential(
                    1.0 / self.config.request_rate, len(samples)
                )
            )
            if open_loop
            else np.zeros(len(samples))
        )
        dispatch_start = loop.time()

        async def _limited(sample: Any, planned_at: float) -> RequestResult:
            if semaphore:
                waited_for_slot = semaphore.locked()
                async with semaphore:
                    sent_at = loop.time()
                    result = await send_fn(session, sample)
                result.waited_for_slot = waited_for_slot
            else:
                sent_at = loop.time()
                result = await send_fn(session, sample)
            if open_loop:
                result.dispatch_lateness_s = sent_at - planned_at
            pbar.update(1)
            return result

        try:
            tasks: list[asyncio.Task] = []
            for sample, offset in zip(samples, planned_offsets):
                planned_at = dispatch_start + float(offset)
                if open_loop:
                    await asyncio.sleep(max(0.0, planned_at - loop.time()))
                tasks.append(asyncio.create_task(_limited(sample, planned_at)))

            results: list[RequestResult] = list(await asyncio.gather(*tasks))
        finally:
            pbar.close()
        return results
