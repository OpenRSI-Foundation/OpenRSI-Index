# SPDX-License-Identifier: Apache-2.0
"""Shared data structures for the benchmark framework."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class RequestResult:
    request_id: str = ""
    text: str = ""
    is_success: bool = False
    latency_s: float = 0.0
    audio_duration_s: float = 0.0
    rtf: float = 0.0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    engine_time_s: float = 0.0
    tok_per_s: float = 0.0
    wav_path: str = ""
    error: str = ""
    audio_ttfp_s: float | None = None
    inter_chunk_s: list[float] = field(default_factory=list)
    chunk_audio_duration_s: list[float] = field(default_factory=list)
    max_playback_underrun_s: float | None = None
    text_ttft_s: float | None = None
    audio_chunk_count: int = 0
    first_audio_payload_bytes: int = 0
    # note (luojiaxuan): the client-side slot cap was busy when this request
    # arrived, so its clock started late and it was not open loop.
    waited_for_slot: bool = False
    # note (luojiaxuan): open-loop runs only; how long after its planned
    # arrival the request was actually sent.
    dispatch_lateness_s: float | None = None
