# SGLang Omni Benchmarks

Benchmark suite for SGLang Omni, covering performance (latency, throughput, RTF)
and accuracy (WER, MMSU, MMMU, Video-MME, Video-AMME) across supported modality
combinations.

## Directory Structure

```
benchmarks/
├── tasks/          # Per-task logic (tts, audio_understanding, visual_understand, video_understanding)
├── metrics/        # Metric computation (performance, accuracy)
├── dataset/        # Dataset loaders + download helpers
├── benchmarker/    # Framework: runner, data structures, utilities
├── eval/           # Entry-point scripts (one per task × model)
├── tts_serving/    # TTS serving harness and Docker contract
├── cache/          # (gitignored) dataset caches
└── results/        # (gitignored) evaluation outputs
```

PersonaPlex reference comparisons: [evaluation setup and limits](eval/personaplex.md).

## Quick Start

```bash
# 0. Prepare dataset (once)
python -m benchmarks.dataset.prepare --dataset seedtts

# 1. Start a server on port 8000 (pick one matching the benchmark below)

# S2-Pro — for sections 2a/2b/2c
python -m sglang_omni.cli serve \
    --model-path fishaudio/s2-pro \
    --config examples/configs/s2pro_tts.yaml --port 8000

# Voxtral-4B-TTS — for section 2d (plain TTS, no voice cloning)
python -m sglang_omni.cli serve \
    --model-path mistralai/Voxtral-4B-TTS-2603 --port 8000

# Higgs TTS — for section 2e (voice cloning via references[])
python -m sglang_omni.cli serve \
    --model-path boson-sglang/higgs-audio-v3-tts-4b-base \
    --port 8000

# MOSS-TTS — for section 2f (voice cloning via references[], duration via token_count)
python -m sglang_omni.cli serve \
    --model-path OpenMOSS-Team/MOSS-TTS-v1.5 \
    --config examples/configs/moss_tts.yaml --port 8000

# Qwen3-Omni, speech mode — for section 3 (SeedTTS; multi-GPU)
python -m sglang_omni.cli serve \
    --model-path Qwen/Qwen3-Omni-30B-A3B-Instruct --port 8000

# Qwen3-Omni, text-only mode — for sections 4 (MMSU) and 5 (MMMU)
python -m sglang_omni.cli serve \
    --model-path Qwen/Qwen3-Omni-30B-A3B-Instruct --text-only --port 8000

# 2a. S2-Pro — full pipeline: generate + WER (server needed for phase 1 only)
python -m benchmarks.eval.benchmark_tts_seedtts \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --model fishaudio/s2-pro --port 8000 \
    --output-dir results/s2pro_en --lang en --max-samples 50 --concurrency 8

# 2b. S2-Pro — generate only (speed metrics, no transcription)
python -m benchmarks.eval.benchmark_tts_seedtts \
    --generate-only --stream \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --model fishaudio/s2-pro --port 8000 --max-samples 50 --concurrency 8

# 2c. S2-Pro — transcribe only (reuses audio from a prior generate run; no server)
python -m benchmarks.eval.benchmark_tts_seedtts \
    --transcribe-only \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --model fishaudio/s2-pro \
    --output-dir results/s2pro_en --lang en --device cuda:0

# 2d. Voxtral — full pipeline without voice cloning
python -m benchmarks.eval.benchmark_tts_seedtts \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --model mistralai/Voxtral-4B-TTS-2603 --port 8000 \
    --max-concurrency 16 \
    --output-dir results/voxtral_en --lang en --max-samples 50 \
    --no-ref-audio --voice cheerful_female

# 2e. Higgs TTS — full pipeline with SeedTTS voice-cloning references
python -m benchmarks.eval.benchmark_tts_seedtts \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --model boson-sglang/higgs-audio-v3-tts-4b-base --port 8000 \
    --ref-format references \
    --max-concurrency 16 \
    --output-dir results/higgs_tts_en --lang en --max-samples 50

# 2f. MOSS-TTS — full pipeline with SeedTTS voice-cloning references
python -m benchmarks.eval.benchmark_tts_seedtts \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --model OpenMOSS-Team/MOSS-TTS-v1.5 --port 8000 \
    --ref-format references --token-count auto \
    --max-concurrency 8 \
    --output-dir results/moss_tts_en --lang en --max-samples 50

# 3a. Qwen3-Omni — full pipeline (generate + transcribe)
python -m benchmarks.eval.benchmark_omni_seedtts \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --output-dir results/qwen3_omni_en \
    --max-concurrency 16 \
    --model qwen3-omni --port 8000 --max-samples 50

# 3b. Qwen3-Omni — generate only (server required; use in CI to split phases)
python -m benchmarks.eval.benchmark_omni_seedtts \
    --generate-only \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --output-dir results/qwen3_omni_en \
    --max-concurrency 16 \
    --model qwen3-omni --port 8000 --max-samples 50

# 3c. Qwen3-Omni — transcribe only (reuses audio; ASR server on --port)
python -m benchmarks.eval.benchmark_omni_seedtts \
    --transcribe-only \
    --meta zhaochenyang20/seed-tts-eval-arrow \
    --output-dir results/qwen3_omni_en \
    --model qwen3-omni --lang en --port 8000

# 3d. Qwen3-Omni — warm the full speech path with separate references before timing
python -m benchmarks.eval.benchmark_omni_seedtts \
    --generate-only --voice-clone --stream \
    --meta measured/meta.lst --warmup-meta warmup/meta.lst \
    --warmup 16 --max-concurrency 16 \
    --output-dir results/qwen3_omni_en --model qwen3-omni --port 8000

# 4. Qwen3-Omni — MMSU (audio comprehension)
python -m benchmarks.eval.benchmark_omni_mmsu \
    --model qwen3-omni --port 8000 \
    --modalities text+audio --max-samples 50

# 5a. Qwen3-Omni — MMAU (audio comprehension)
python -m benchmarks.eval.benchmark_omni_mmau \
    --model qwen3-omni --port 8000 --max-samples 50

# 5b. Qwen3-Omni — MMAR (audio reasoning)
python -m benchmarks.eval.benchmark_omni_mmar \
    --model qwen3-omni --port 8000 --max-samples 50

# 6. Qwen3-Omni — MMMU (VLM accuracy, image input)
python -m benchmarks.eval.benchmark_omni_mmmu \
    --model qwen3-omni --port 8000 --max-samples 50 --max-concurrency 16

# 7. Qwen3-Omni — Video-MME (video understanding)
python -m benchmarks.eval.benchmark_omni_videomme \
    --model qwen3-omni --port 8000 --max-samples 50

# 8a. Qwen3-Omni — Video-AMME (video + audio question understanding)
python -m benchmarks.eval.benchmark_omni_videoamme \
    --model qwen3-omni --port 8000 \
    --repo-id zhaochenyang20/Video_AMME_ci \
    --max-samples 50 --max-concurrency 16 \
    --video-fps 2 --video-max-frames 128 --video-max-pixels 401408

# 8b. Qwen3-Omni — Video-AMME Talker (text + audio output)
python -m benchmarks.eval.benchmark_omni_videoamme \
    --model qwen3-omni --port 8000 \
    --repo-id zhaochenyang20/Video_AMME_ci \
    --max-samples 50 --max-concurrency 16 \
    --video-fps 2 --video-max-frames 128 --video-max-pixels 401408 \
    --enable-audio --asr-device cuda:0 --asr-concurrency 32

# 8a. Offline UTMOS (naturalness MOS prediction) scoring on existing output
# For custom TTS models (e.g. S2-Pro, Voxtral, Higgs TTS):
python -m benchmarks.eval.benchmark_tts_seedtts \
    --utmos-only --output-dir results/s2pro_en --device cuda:0

# For Qwen3-Omni:
python -m benchmarks.eval.benchmark_omni_seedtts \
    --utmos-only --output-dir results/qwen3_omni_en --device cuda:0

# 8b. Offline Speaker Similarity (voice resemblance) scoring on existing output
# For custom TTS models (e.g. S2-Pro, Voxtral, Higgs TTS):
python -m benchmarks.eval.benchmark_tts_seedtts \
    --similarity-only --output-dir results/s2pro_en --device cuda:0

# For Qwen3-Omni:
python -m benchmarks.eval.benchmark_omni_seedtts \
    --similarity-only --output-dir results/qwen3_omni_en --device cuda:0
```

## Eval Scripts

| Script | Task | Model | API |
|--------|------|-------|-----|
| `eval/benchmark_tts_seedtts.py` | TTS speed + WER (unified) | e.g. S2-Pro, Voxtral, Higgs TTS | `/v1/audio/speech` |
| `eval/benchmark_tts_serving.py` | TTS serving contract | OpenAI-compatible TTS models | `/v1/audio/speech`, raw PCM streaming, WebSocket, voice and batch contracts |
| `eval/benchmark_omni_seedtts.py` | TTS speed + WER (unified) | Qwen3-Omni, MiniCPM-o | `/v1/chat/completions` |
| `eval/benchmark_omni_mmsu.py` | MMSU (audio comprehension) | Qwen3-Omni | `/v1/chat/completions` |
| `eval/benchmark_omni_mmau.py` | MMAU (audio comprehension) | Qwen3-Omni | `/v1/chat/completions` |
| `eval/benchmark_omni_mmar.py` | MMAR (audio reasoning) | Qwen3-Omni | `/v1/chat/completions` |
| `eval/benchmark_omni_mmmu.py` | MMMU (VLM accuracy + speed) | Qwen3-Omni | `/v1/chat/completions` |
| `eval/benchmark_omni_videomme.py` | Video-MME (video understanding) | Qwen3-Omni | `/v1/chat/completions` |
| `eval/benchmark_omni_videoamme.py` | Video-AMME (video + audio question understanding) | Qwen3-Omni | `/v1/chat/completions` |
| `eval/benchmark_asr_seedtts.py` | ASR concurrency scaling on SeedTTS EN/ZH | Qwen3-ASR, Fun-ASR | `/v1/audio/transcriptions` |
| `eval/benchmark_asr_stt_benchmark.py` | ASR concurrency scaling on the Pipecat STT benchmark set (EN) | Qwen3-ASR, Fun-ASR | `/v1/audio/transcriptions` |
| `eval/benchmark_asr_longform.py` | ASR concurrency scaling on LongLibriHeavy 30/60 s and Meanwhile (EN) | Qwen3-ASR, Fun-ASR | `/v1/audio/transcriptions` |
| `eval/benchmark_asr_realtime.py` | Realtime ASR streaming latency, protocol invariants, and WER on SeedTTS EN | Qwen3-ASR | `/v1/realtime?intent=transcription` |

See [tts_serving/README.md](tts_serving/README.md) for the TTS serving
benchmark design, harness contract, scenario matrix, and Docker usage.

The two `*_seedtts.py` scripts merge the previous `benchmark_*_tts_speed.py`
and `voice_clone_*_wer.py` pairs into a single two-phase pipeline: phase 1
generates + persists WAVs while the TTS server runs, phase 2 transcribes through
an ASR server to avoid GPU contention with the TTS server. Use `--generate-only` or
`--transcribe-only` to run a single phase. For TTS, `--concurrency` and
`--max-concurrency` are equivalent (see `benchmark_tts_seedtts.py`).
`benchmark_tts_seedtts.py` also handles model-specific voice-cloning reference
payloads: the default `--ref-format flat` sends `ref_audio`/`ref_text`, while
`--ref-format references` sends `references=[{audio_path, text}]` for Higgs TTS
and MOSS-TTS. MOSS-TTS additionally supports duration control through
`--token-count`. `--seed`, `--temperature`, `--top-p`, `--top-k`, and
`--repetition-penalty` are recorded in the speed results. Reference audio on
this endpoint is a filesystem path, so it is not client-encoded inside the
request timer. `--concurrencies 1,16 --repeats 5 --generate-only` repeats each
level. One repeat keeps the directory `c<level>`; further repeats write
`c<level>_r<repeat>`. Every row in `concurrency_sweep.json` is an aggregate
of the same speed metrics as the Omni sweep, with `per_repeat` holding each
raw summary.
`--fingerprint` records the client environment and the server `/v1/models`
identity.

Chat-completion speed runs forward `--seed` on the request when it is set
(MMSU, MMAU, and MMAR also use it to shuffle the dataset) and accept
`--fingerprint`. `benchmark_omni_streaming_ttft.py` uses one `--seed` for
warmup and every measured repeat, and records talker sampling knobs.
`benchmark_omni_rollout_stress.py` derives request seed `base + index` from
`--seed` so rollouts differ but stay reproducible. The realtime ASR client
base64-encodes packets before the first-send timestamp.

`benchmark_omni_seedtts.py` documents local vs CI GPU usage in its module
docstring (sequential phases on CI to reduce OOM risk).

Omni warmup runs in the benchmark client after the server is available. By
default it repeats one sample concurrently; `--warmup 0` disables it. Use
`--warmup-meta` with a separate SeedTTS metadata file or dataset to exercise
different reference audio and prompts. Supply at least `--warmup` samples
(the request count defaults to `--max-concurrency`), and choose references and
text outside the measured set to avoid warming its per-sample caches. Use
`--voice-clone --stream` to exercise reference encoding and streaming audio.
Warmup uses normal generation limits and EOS handling; it does not guarantee
that every stage reaches the requested concurrency as one batch.

Separate warmup saves audio and per-request outcomes under `<output-dir>/warmup/`.
All requests must succeed before the measured cohort starts. These outputs
and their wall time are excluded from the main speed results and generated
audio metadata. Apply the same warmup policy to both benchmark revisions;
measure startup-to-ready and the first unconditioned request wave separately
when evaluating production cold starts.

For MiniCPM-o, pass `--voice-clone --reference-audio-field audio.ref_audio`.
The client encodes every reference WAV once before the timed run so file
reads stay out of request latency. `--seed` sends one sampler seed with every
request so generated lengths are reproducible between A/B runs; the seed and
temperature are recorded in the results config.
Seeded sampling is not free: SGLang's seeded sampler hashes every vocabulary
entry per token, which measured about 8% extra latency at concurrency 1 on an
A6000 with identical output. Use the same seed setting in both arms of an A/B
comparison and never compare seeded against unseeded absolute numbers.
`--talker-temperature`, `--talker-top-p`, `--talker-top-k` and
`--talker-repetition-penalty` pin the talker's sampling and are recorded the
same way; unset knobs keep the server defaults. `--fingerprint` records the
client environment and the server's `/v1/models` identity in the results
config, using the same helpers as the ASR sweeps.

`--concurrencies 1,16 --repeats 5 --generate-only` sweeps concurrency levels,
writing each run to `<output-dir>/c<level>_r<repeat>/` and one
`<output-dir>/sweep.json` that aggregates each level's repeats (mean, min,
max, n per metric) with the raw per-repeat summaries, in the same shape as
the ASR sweeps. Tail percentiles need at least 100
measured samples; below that p99 interpolates the two slowest requests and the
benchmark logs a warning. Without `--warmup-meta` the warmup replays the first
measured sample, so its server caches are warm when it is timed.

`benchmark_asr_seedtts.py` is a standalone ASR fan-out sweep (issue #646): it
transcribes the SeedTTS *reference* clips directly against a running Qwen3-ASR
or Fun-ASR router and reports WER + speed + per-worker routing balance per
concurrency level. It reports evaluation coverage and RTFx (successful
input-audio seconds per wall-clock second) alongside the existing RTF. Use it
to measure how ASR concurrency affects capacity, latency, and WER for a given
workload.

Add `--stream` to exercise the transcription SSE path and report text TTFT and
inter-chunk latency while retaining the terminal transcript for WER:

```bash
python -m benchmarks.eval.benchmark_asr_seedtts \
  --model-path FunAudioLLM/Fun-ASR-Nano-2512-hf --port 8000 \
  --max-samples 20 --concurrencies 2 --repeats 1 --stream
```

`benchmark_asr_stt_benchmark.py` runs the same sweep on
[`pipecat-ai/stt-benchmark-data`](https://huggingface.co/datasets/pipecat-ai/stt-benchmark-data):
1000 English utterances, 1 to 16 s each (9.6 s mean), with punctuated, cased
transcripts. Where SeedTTS measures short clean prompts, this set measures
the longer conversational turns a voice agent sees. The script imports the
sweep loop, table, and common arguments from `benchmark_asr_seedtts.py`, so
both result JSONs share one `config`/`results` layout and differ only in the
dataset fields (`repo_id`/`split` instead of `meta`).

This only reuses Pipecat's dataset, not their metric definitions. The upstream
[pipecat-ai/stt-benchmark](https://github.com/pipecat-ai/stt-benchmark)
reports Semantic WER and TTFS (end of speech to final transcript over a
simulated realtime stream); this sweep reports Whisper-normalized WER and
whole-request latency/RTF, and `--stream` uploads the complete file. The
numbers are not comparable to the Pipecat leaderboard.

```bash
python -m benchmarks.dataset.prepare --dataset stt-benchmark
python -m benchmarks.eval.benchmark_asr_stt_benchmark \
  --port 8000 --concurrencies 1,8,32 --repeats 3 --warmup
```

`benchmark_asr_longform.py` registers three canonical long-form English
workloads: the complete LongLibriHeavy `llh_test_30` (1203 samples) and
`llh_test_60` (591 samples) splits, plus all 64 samples in the Meanwhile `test`
split. The LongLibriHeavy names refer to the published splits; the loader does
not apply another duration filter. Likewise, Meanwhile's `begin` and `end`
metadata are not used to crop the already segmented `audio` field.

The loader decodes each source clip and stages it as mono 16 kHz PCM WAV before
the timed sweep. The result JSON uses the same schema and metrics as the
SeedTTS and Pipecat ASR sweeps, and records the dataset alias, repository,
split, pinned revision, expected sample count, and exact input fingerprint.
`--stream` uploads each complete file rather than simulating real-time audio
arrival.

```bash
python -m benchmarks.dataset.prepare --dataset longlibriheavy-30
python -m benchmarks.eval.benchmark_asr_longform \
  --dataset longlibriheavy-30 --port 8000 \
  --concurrencies 1,8,32 --repeats 3 --warmup

python -m benchmarks.dataset.prepare --dataset longlibriheavy-60
python -m benchmarks.eval.benchmark_asr_longform \
  --dataset longlibriheavy-60 --port 8000 \
  --concurrencies 1,8,32 --repeats 3 --warmup

python -m benchmarks.dataset.prepare --dataset meanwhile
python -m benchmarks.eval.benchmark_asr_longform \
  --dataset meanwhile --port 8000 \
  --concurrencies 1,8,32 --repeats 3 --warmup
```

`benchmark_asr_realtime.py` streams SeedTTS reference clips through the
realtime WebSocket endpoint (`--enable-realtime`) at wall-clock pace and
reports client-observed streaming latencies, protocol invariant violations, and
WER of the completed transcript. The client (`benchmarks/realtime_asr/client.py`)
only records timestamps; every metric definition lives in
`benchmarks/realtime_asr/metrics.py` so numbers stay comparable across runs:

- `first_partial_latency_s`: per segment, from the send time of the packet that
  reached the server's first refresh point (`segment_start + decode_interval_ms`)
  to the first partial `transcription.segment`.
- `partial_interval_s`: gaps between consecutive partials of one segment.
- `final_latency_s`: `input_audio_buffer.committed` to the segment's final event.
- `done_to_completed_s`: `transcription.done` sent to `transcription.completed`.

`--mode vad` (default) lets server VAD close turns and pads each clip with
`--trailing-silence-ms` of silence so the last turn closes on VAD; `--mode
manual` disables VAD and commits explicitly. `--http-baseline` transcribes the
same clips over `/v1/audio/transcriptions`; the WER delta is computed only on
samples that succeeded on both paths (`common_evaluated`) and is `null` when
that set is empty.
`--concurrencies` runs one result per level; there is no cross-level report.
The `decode_interval_ms` in effect is read from `session.created` and recorded
in the result `config`.

```bash
python -m benchmarks.eval.benchmark_asr_realtime \
  --port 8000 --max-samples 50 --concurrencies 1,4,8 --http-baseline
```

Both `*_seedtts.py` scripts also support speech quality and similarity evaluation via UTMOS and WavLM speaker verification metrics. Running with `--utmos-only` or `--similarity-only` loads the respective pre-trained predictor and computes scores on the previously generated audio in the output directory without requiring the TTS/ASR servers to be running.

## TTS Quality Evaluation

To evaluate the overall quality and vocal resemblance of synthesized speech, the benchmark suite supports offline evaluation using UTMOS (naturalness MOS prediction) and Speaker Similarity (vocal fidelity).

### UTMOS (Naturalness)

UTMOS (UTokyo-Saru Lab MOS Prediction) is a Mean Opinion Score (MOS) predictor model used to evaluate the naturalness and overall quality of synthesized speech. SGLang Omni provides an offline UTMOS evaluator backed by the `balacoon/utmos` JIT model on Hugging Face.

- **Model Weights Cache**: By default, weights (`utmos.jit`) are downloaded from Hugging Face on the first run and cached at `~/.cache/sglang-omni/utmos` (override via `UTMOS_CACHE_DIR` environment variable).
- **Warm the Cache (Optional)**:
  ```bash
  python -m benchmarks.metrics.utmos --warm-cache
  ```
- **Outputs (`utmos_results.json`)**:
  - `summary`: section for summary metrics
    - `utmos_mean`: Mean predicted MOS score in `[1, 5]` (higher is better).
    - `utmos_median`: Median predicted MOS score.
    - `utmos_p5` / `utmos_p95`: 5th and 95th percentile scores to identify worst-case outliers or top-performing samples.
    - `total_samples`: total number of samples in the dataset.
    - `evaluated`: number of samples that were evaluated.
    - `skipped`: number of samples that were skipped.
  - `config`: evaluation configuration parameters.
  - `per_sample`: list of individual score results for each evaluated sample.

### Speaker Similarity (Vocal Fidelity)

Speaker Similarity evaluates how closely the voice of synthesized speech matches the reference prompt audio.

- **Model Weights Cache**: By default, model weights (`wavlm_large.pt` and `wavlm_large_finetune.pth`) are downloaded from Hugging Face and cached at `~/.cache/sglang-omni/speaker_sim` (override via `SEEDTTS_SIM_CACHE_DIR` environment variable).
- **Warm the Cache (Optional)**:
  ```bash
  python -m benchmarks.metrics.speaker_similarity_assets --warm-cache
  ```
- **Outputs (`similarity_results.json`)**:
  - `summary`: section for summary metrics
    - `speaker_similarity_mean`: Mean cosine similarity score scaled by 100.0 (higher is better).
    - `total_samples`: total number of samples in the dataset.
    - `evaluated`: number of samples that were evaluated.
    - `skipped`: number of samples that were skipped.
  - `config`: evaluation configuration parameters.
  - `per_sample`: list of individual score results for each evaluated sample.

## Adding a New Model or Task

- **New model, same task/API type** (e.g. another OAI-compatible TTS model):
  add an eval script under `eval/` that reuses the existing task helpers
  in `tasks/tts.py` (`make_tts_send_fn`, `run_seedtts_transcribe`, …).
- **New task or API type**: add a task class in the relevant `tasks/*.py`
  file (mirroring `VoiceCloneOmni` in `tasks/tts.py`), expose metric
  helpers, and wire it into a new eval script.

## Datasets

Download helpers live in `benchmarks/dataset/prepare.py`:

```bash
python -m benchmarks.dataset.prepare --dataset seedtts       # full SeedTTS
python -m benchmarks.dataset.prepare --dataset seedtts-mini  # smoke-test subset
python -m benchmarks.dataset.prepare --dataset seedtts-50    # 50-sample subset
python -m benchmarks.dataset.prepare --dataset stt-benchmark # Pipecat STT benchmark set (1000 EN clips)
python -m benchmarks.dataset.prepare --dataset longlibriheavy-30  # LongLibriHeavy llh_test_30 only
python -m benchmarks.dataset.prepare --dataset longlibriheavy-60  # LongLibriHeavy llh_test_60 only
python -m benchmarks.dataset.prepare --dataset meanwhile     # complete Meanwhile test split (64 EN clips)
python -m benchmarks.dataset.prepare --dataset mmmu          # full MMMU (30 subjects)
python -m benchmarks.dataset.prepare --dataset mmmu-ci-50    # MMMU CI subset
python -m benchmarks.dataset.prepare --dataset mmsu          # full MMSU (ddwang2000/MMSU)
python -m benchmarks.dataset.prepare --dataset mmau-mini     # MMAU test_mini split
python -m benchmarks.dataset.prepare --dataset mmar          # MMAR metadata + audio archive
python -m benchmarks.dataset.prepare --dataset videomme-ci-50  # Video-MME CI subset
python -m benchmarks.dataset.prepare --dataset videomme      # full Video-MME
python -m benchmarks.dataset.prepare --dataset videoamme-ci-50  # Video-AMME CI subset
```

All datasets are pre-warmed into the default HuggingFace cache via
`datasets.load_dataset(repo_id)`.  SeedTTS Arrow repos stage audio to
process-local tempfiles at load time; no manual `--local-dir` step is needed.

Video-AMME is generated from the Video-MME CI subset by moving the
question/options/instruction into per-sample WAV files. The benchmark request
text only contains routing/format instructions; the actual question content
stays in the dataset WAV files.
