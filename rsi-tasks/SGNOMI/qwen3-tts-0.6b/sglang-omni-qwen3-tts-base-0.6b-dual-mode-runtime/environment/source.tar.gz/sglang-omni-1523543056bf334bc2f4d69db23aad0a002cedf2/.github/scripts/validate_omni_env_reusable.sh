#!/usr/bin/env bash
# Strict gate for reusing an existing OMNI_CI_HOME venv across workflow runs.
#
# Checks path safety, dependency fingerprint (when recorded), import probe,
# and exact == pins. Missing .deps-hash is allowed when the venv itself matches
# pyproject.toml (e.g. prior setup installed packages but failed a post-install gate).
# Does not require .omni-env-complete (downstream jobs use this gate; setup writes marker).
set -euo pipefail

source "$(dirname "${BASH_SOURCE[0]}")/pin_to_ci_cpuset.sh"

if [ "$#" -ne 1 ]; then
  echo "usage: $0 <venv-name>" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV_NAME="$1"

bash "${SCRIPT_DIR}/validate_omni_ci_home.sh"

if [ ! -f pyproject.toml ]; then
  echo "pyproject.toml not found in $(pwd); run from repository root" >&2
  exit 1
fi

# shellcheck source=omni_ci_deps_hash.sh
source "${SCRIPT_DIR}/omni_ci_deps_hash.sh"
DEPS_HASH="$(omni_ci_deps_hash)"
DEPS_HASH_FILE="${OMNI_CI_HOME}/.deps-hash"

PYTHON="${OMNI_CI_HOME}/${VENV_NAME}/bin/python"
if [ ! -x "${PYTHON}" ]; then
  echo "python not found: ${PYTHON}" >&2
  exit 1
fi

if ! "${PYTHON}" -c 'import sys; raise SystemExit(sys.version_info[:2] != (3, 12))'; then
  echo "OMNI CI venv must use the image Python 3.12 ABI" >&2
  exit 1
fi

if ! grep -Eq '^include-system-site-packages = true$' "${OMNI_CI_HOME}/${VENV_NAME}/pyvenv.cfg"; then
  echo "OMNI CI venv must inherit the image site-packages" >&2
  exit 1
fi

if ! "${PYTHON}" - <<'PY'
from pathlib import Path
import sys
import flashinfer
import torch

venv = Path(sys.prefix).resolve()
for module in (flashinfer, torch):
    if Path(module.__file__).resolve().is_relative_to(venv):
        raise SystemExit(f"{module.__name__} must come from the image, not {venv}")
PY
then
  echo "Torch and FlashInfer must use the image installation for JIT cache reuse" >&2
  exit 1
fi

if ! "${PYTHON}" "${SCRIPT_DIR}/omni_missing_dependencies.py" --check --extra minicpm-o --extra fun-cosyvoice3 pyproject.toml; then
  exit 1
fi

if [ -f "${DEPS_HASH_FILE}" ]; then
  STORED_HASH="$(tr -d '[:space:]' < "${DEPS_HASH_FILE}")"
  if [ "${STORED_HASH}" != "${DEPS_HASH}" ]; then
    echo "deps-hash mismatch: stored=${STORED_HASH} current=${DEPS_HASH}" >&2
    echo "CI dependencies or preparation script changed; full environment rebuild required" >&2
    exit 1
  fi
else
  echo "Note: ${DEPS_HASH_FILE} missing; validating installed venv against pyproject.toml"
fi

if ! bash "${SCRIPT_DIR}/validate_omni_venv_imports.sh" "${VENV_NAME}"; then
  exit 1
fi

if ! bash "${SCRIPT_DIR}/verify_omni_installed_pins.sh" "${VENV_NAME}"; then
  echo "installed dependency pins do not match pyproject.toml" >&2
  exit 1
fi

echo "OMNI CI environment reusable: ${OMNI_CI_HOME} (venv=${VENV_NAME}, deps_hash=${DEPS_HASH})"
