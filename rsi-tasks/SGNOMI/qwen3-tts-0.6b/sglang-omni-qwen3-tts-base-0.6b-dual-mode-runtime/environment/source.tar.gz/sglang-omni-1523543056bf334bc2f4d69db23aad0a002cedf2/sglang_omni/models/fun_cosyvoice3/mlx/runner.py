# SPDX-License-Identifier: Apache-2.0
"""SGLang MLX runner adapter for Fun-CosyVoice3 speech-token decoding."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

import mlx.core as mx
import numpy as np

from .model import SPEECH_TOKEN_SIZE

if TYPE_CHECKING:
    from sglang.srt.hardware_backend.mlx.kv_cache.attention_kv_cache import (
        ContiguousAttentionKVCache,
    )
    from sglang.srt.hardware_backend.mlx.model_runner import (
        MlxModelRunner,
        MlxPendingDecode,
        MlxPendingPrefill,
    )
    from sglang.srt.hardware_backend.mlx.sampling import (
        MlxLazyLogprobs,
        MlxLogprobSpec,
        MlxSamplingParams,
    )
    from sglang.srt.managers.schedule_batch import Req
else:
    pass

_SPEECH_IDS = mx.arange(SPEECH_TOKEN_SIZE, dtype=mx.int32)
# Note (yexiaodong): MLX streams are thread-local; bind this lookup on the
# construction thread so scheduler-thread graphs do not retain stream 0.
mx.eval(_SPEECH_IDS)


class FunCosyVoice3MlxModelRunner:
    """Customize only prompt prefill; generic MLX cache/decode stays upstream."""

    def _load_model(self) -> None:
        from sglang.srt.hardware_backend.mlx.remote_code_gate import (
            ensure_remote_code_allowed,
            resolve_model_directory,
        )

        from .model import load_cosyvoice3_mlx_model

        model_dir = resolve_model_directory(self.model_path, revision=self.revision)
        ensure_remote_code_allowed(model_dir, self.trust_remote_code)
        self.model = load_cosyvoice3_mlx_model(
            model_dir,
            quantization=self._quantization,  # noqa: leading-underscore
        )
        self._trunk = None  # noqa: leading-underscore

    def __init__(self, *args: object, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)
        self.cosyvoice3_prompt_lengths: dict[str, int] = {}
        self.cosyvoice3_min_lengths: dict[str, int] = {}
        self.cosyvoice3_repetition_penalties: dict[str, float] = {}
        self.cosyvoice3_seen_masks: dict[str, mx.array] = {}
        self.cosyvoice3_recent_tokens: dict[str, list[int]] = {}
        self.cosyvoice3_sampling_pending_tokens: mx.array | None = None

    @staticmethod
    def request_prompt(
        req: "Req",
    ) -> tuple[list[int], list[int]]:
        text_ids = getattr(
            req, "_cosyvoice3_text_token_ids", None
        )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        prompt_ids = getattr(
            req, "_cosyvoice3_prompt_speech_token_ids", None
        )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        if text_ids is None or prompt_ids is None:
            raise ValueError(
                "Fun-CosyVoice3 MLX request is missing raw prompt token metadata"
            )
        else:
            pass
        return list(text_ids), list(prompt_ids)

    def constrain_logits(
        self,
        logits: mx.array,
        req_ids: list[str],
        caches: list[list[ContiguousAttentionKVCache]],
        *,
        initial: bool = False,
        pending_tokens: mx.array | None = None,
    ) -> mx.array:
        """Apply Omni's stop and repetition constraints before sampling."""
        rows = []
        for index, req_id in enumerate(req_ids):
            row = logits[index]
            prompt_length = self.cosyvoice3_prompt_lengths.get(req_id, 0)
            if initial:
                generated_count = 0
            else:
                generated_count = max(
                    self._first_attention_cache(caches[index]).offset
                    - prompt_length,  # noqa: leading-underscore
                    0,
                )
            if generated_count < self.cosyvoice3_min_lengths.get(req_id, 0):
                row = mx.concatenate(
                    [
                        row[:SPEECH_TOKEN_SIZE],
                        mx.full_like(row[SPEECH_TOKEN_SIZE:], -float("inf")),
                    ]
                )
            else:
                pass

            penalty = self.cosyvoice3_repetition_penalties.get(req_id, 1.0)
            if penalty != 1.0:
                seen = self.cosyvoice3_seen_masks[req_id]
                if pending_tokens is not None:
                    # Note (yexiaodong): Chained steps share a lazy predecessor;
                    # carry its token so repetition state remains exact.
                    seen = seen | (_SPEECH_IDS == pending_tokens[index])
                else:
                    pass
                speech_logits = row[:SPEECH_TOKEN_SIZE]
                adjusted = mx.where(
                    speech_logits > 0,
                    speech_logits / penalty,
                    speech_logits * penalty,
                )
                speech_logits = mx.where(seen, adjusted, speech_logits)
            else:
                seen = self.cosyvoice3_seen_masks[req_id]
                if pending_tokens is not None:
                    seen = seen | (_SPEECH_IDS == pending_tokens[index])
                else:
                    pass
                speech_logits = row[:SPEECH_TOKEN_SIZE]

            row = mx.concatenate([speech_logits, row[SPEECH_TOKEN_SIZE:]])
            rows.append(row)
        return mx.stack(rows)

    def prefill_start(
        self,
        req_id: str,
        new_token_ids: list[int],
        full_token_ids: list[int],
        prefix_slot_ids: list[int],
        new_slot_ids: list[int],
        req_pool_idx: int,
        req: "Req | None" = None,
        needs_logits: bool = True,
        logit_edit_row: mx.array | None = None,
        logprob_spec: MlxLogprobSpec | None = None,
    ) -> MlxPendingPrefill:
        from sglang.srt.hardware_backend.mlx.model_runner import MlxPendingPrefill

        del new_token_ids, new_slot_ids
        if req is None:
            raise ValueError(
                "Fun-CosyVoice3 MLX prefill requires its scheduler request"
            )
        else:
            pass
        if prefix_slot_ids:
            raise NotImplementedError(
                "Fun-CosyVoice3 MLX does not support radix-cache prefixes yet"
            )
        else:
            pass
        if not self.disable_radix_cache:
            raise RuntimeError("Fun-CosyVoice3 MLX requires disable_radix_cache=True")
        else:
            pass

        if self._enable_sampling:  # noqa: leading-underscore
            self._req_sampling[req_id] = self.sampling_params_for_request(
                req
            )  # noqa: leading-underscore
        else:
            pass
        self.cosyvoice3_prompt_lengths[req_id] = len(full_token_ids)
        self.cosyvoice3_min_lengths[req_id] = int(req.sampling_params.min_new_tokens)
        self.cosyvoice3_repetition_penalties[req_id] = float(
            req.sampling_params.repetition_penalty
        )
        self.cosyvoice3_seen_masks[req_id] = mx.zeros(
            (SPEECH_TOKEN_SIZE,), dtype=mx.bool_
        )
        self.cosyvoice3_recent_tokens[req_id] = []
        text_ids, prompt_ids = self.request_prompt(req)
        embeddings = self.model.build_prompt_embeddings(text_ids, prompt_ids)
        cache = self._acquire_cache()  # noqa: leading-underscore
        logits = self.model.forward_embeddings(embeddings, cache=cache)
        logits = self.constrain_logits(
            logits[:, -1, :],
            [req_id],
            [cache],
            initial=True,
        )
        lazy_token, lazy_logprobs = self._select_tokens_with_logprobs(
            logits,
            [req_id],
            [cache],
            logit_edit_row,
            logprob_spec,
        )
        del needs_logits
        return MlxPendingPrefill(
            lazy_token=lazy_token,
            cache=cache,
            req_id=req_id,
            full_token_ids=list(full_token_ids),
            req_pool_idx=req_pool_idx,
            synced_offset=0,
            lazy_logprobs=lazy_logprobs,
        )

    def sampling_params_for_request(self, req: "Req") -> MlxSamplingParams:
        from sglang.srt.hardware_backend.mlx.sampling import (
            DEFAULT_SAMPLING_SEED,
            MlxSamplingParams,
        )

        sampling_params = req.sampling_params
        # Note (yexiaodong): Preserve the request seed when global deterministic
        # inference is disabled; global state is only a default.
        seed = sampling_params.sampling_seed
        if seed is None and self._deterministic_seeding:  # noqa: leading-underscore
            seed = DEFAULT_SAMPLING_SEED
        else:
            pass
        # Note (yexiaodong): This runner applies repetition penalties itself,
        # so avoid the shared constructor's misleading warning.
        return MlxSamplingParams(
            temperature=sampling_params.temperature,
            top_k=sampling_params.top_k,
            top_p=sampling_params.top_p,
            min_p=sampling_params.min_p,
            seed=seed,
        )

    def decode_batch_start(
        self,
        req_ids: list[str],
        edit_rows: mx.array | None = None,
        logprob_spec: MlxLogprobSpec | None = None,
        logits_hook: (
            Callable[
                [np.ndarray[tuple[int, ...], np.dtype[np.float32]]],
                np.ndarray[tuple[int, ...], np.dtype[np.float32]],
            ]
            | None
        ) = None,
    ) -> MlxPendingDecode:
        if len(req_ids) != 1:
            return super().decode_batch_start(
                req_ids,
                edit_rows=edit_rows,
                logprob_spec=logprob_spec,
                logits_hook=logits_hook,
            )
        else:
            pass
        from sglang.srt.hardware_backend.mlx.model_runner import MlxPendingDecode

        req_id = req_ids[0]
        cache = self._req_caches[req_id]  # noqa: leading-underscore
        input_ids = mx.array(
            [[self._req_token_ids[req_id][-1]]], dtype=mx.int32
        )  # noqa: leading-underscore
        logits = self._decode_with_native_cache(
            [cache], [input_ids]
        )  # noqa: leading-underscore
        logits = self.constrain_logits(logits, req_ids, [cache])
        if logits_hook is not None:
            logits = self._run_logits_hook(
                logits, logits_hook
            )  # noqa: leading-underscore
        else:
            pass
        lazy_tokens, lazy_logprobs = self._select_tokens_with_logprobs(
            logits,
            req_ids,
            [cache],
            edit_rows,
            logprob_spec,
        )
        return MlxPendingDecode(
            lazy_tokens=lazy_tokens,
            req_ids=req_ids,
            caches=[cache],
            lazy_logprobs=lazy_logprobs,
            logprob_spec=logprob_spec,
            edit_rows=edit_rows,
        )

    def recent_token_masks(
        self,
        req_ids: list[str],
        pending_tokens: mx.array | None,
    ) -> mx.array:
        """Build recent-token masks for CosyVoice's repetition-aware sampler."""
        masks = []
        for index, req_id in enumerate(req_ids):
            mask = mx.zeros((SPEECH_TOKEN_SIZE,), dtype=mx.bool_)
            recent = self.cosyvoice3_recent_tokens.get(req_id, [])
            if recent:
                mask = mask.at[mx.array(recent, dtype=mx.int32)].add(True)
            else:
                pass
            if pending_tokens is not None:
                mask = mask | (_SPEECH_IDS == pending_tokens[index])
            else:
                pass
            masks.append(mask)
        return mx.stack(masks)

    def _select_tokens_with_logprobs(
        self,
        last_logits: mx.array,
        req_ids: list[str],
        caches: list[list[ContiguousAttentionKVCache]],
        edit_rows: mx.array | None = None,
        logprob_spec: MlxLogprobSpec | None = None,
    ) -> tuple[mx.array, MlxLazyLogprobs | None]:
        """Apply CosyVoice RAS fallback around SGLang's MLX sampler.

        The reference sampler first draws from nucleus/top-k and, when that
        candidate appeared in the recent ten-token window, redraws from the
        full distribution with that candidate masked. Keep this entirely in
        the MLX graph so chained decode remains valid.
        """
        if not self._enable_sampling:  # noqa: leading-underscore
            return super()._select_tokens_with_logprobs(
                last_logits,
                req_ids,
                caches,
                edit_rows,
                logprob_spec,
            )
        else:
            pass

        from sglang.srt.hardware_backend.mlx.sampling import (
            MlxSamplingParams,
            compute_logprobs,
            sample_tokens,
            scale_by_temperature,
        )

        params = [
            self._req_sampling[req_id] for req_id in req_ids
        ]  # noqa: leading-underscore
        edited = self._edited_logits(last_logits, edit_rows)  # noqa: leading-underscore
        scaled = scale_by_temperature(edited, params)
        positions = [
            self._first_attention_cache(cache).offset - 1 for cache in caches
        ]  # noqa: leading-underscore
        self._rng_key, first_key = mx.random.split(
            self._rng_key
        )  # noqa: leading-underscore
        first = sample_tokens(
            edited,
            params,
            positions,
            first_key,
            scaled=scaled,
        )

        recent_masks = self.recent_token_masks(
            req_ids,
            self.cosyvoice3_sampling_pending_tokens,
        )
        first_is_speech = first < SPEECH_TOKEN_SIZE
        repeated = first_is_speech & mx.take_along_axis(
            recent_masks,
            mx.minimum(first, SPEECH_TOKEN_SIZE - 1)[:, None],
            axis=1,
        ).squeeze(-1)
        greedy = mx.array([param.is_greedy for param in params], dtype=mx.bool_)
        repeated = repeated & ~greedy

        fallback_params = [
            MlxSamplingParams(
                temperature=param.temperature,
                top_k=1 if param.is_greedy else edited.shape[-1],
                top_p=1.0,
                min_p=0.0,
                seed=param.seed,
            )
            for param in params
        ]
        fallback_mask = _SPEECH_IDS[None, :] == first[:, None]
        fallback_logits = mx.where(
            repeated[:, None] & fallback_mask,
            -float("inf"),
            edited[:, :SPEECH_TOKEN_SIZE],
        )
        fallback_logits = mx.concatenate(
            [fallback_logits, edited[:, SPEECH_TOKEN_SIZE:]], axis=1
        )
        self._rng_key, fallback_key = mx.random.split(
            self._rng_key
        )  # noqa: leading-underscore
        fallback = sample_tokens(
            fallback_logits,
            fallback_params,
            positions,
            fallback_key,
        )
        tokens = mx.where(repeated, fallback, first)

        lazy_logprobs = (
            compute_logprobs(
                last_logits=edited,
                params=params,
                tokens=tokens,
                spec=logprob_spec,
                scaled=scaled,
            )
            if logprob_spec is not None
            else None
        )
        return tokens, lazy_logprobs

    def decode_batch_start_chained(self, prev: MlxPendingDecode) -> MlxPendingDecode:
        if len(prev.req_ids) != 1:
            return super().decode_batch_start_chained(prev)
        else:
            pass
        from sglang.srt.hardware_backend.mlx.model_runner import MlxPendingDecode

        self.cosyvoice3_sampling_pending_tokens = prev.lazy_tokens
        try:
            logits = self._decode_with_native_cache(  # noqa: leading-underscore
                prev.caches,
                [prev.lazy_tokens[:, None]],
            )
            logits = self.constrain_logits(
                logits,
                prev.req_ids,
                prev.caches,
                pending_tokens=prev.lazy_tokens,
            )
            lazy_tokens, lazy_logprobs = self._select_tokens_with_logprobs(
                logits,
                prev.req_ids,
                prev.caches,
                prev.edit_rows,
                prev.logprob_spec,
            )
        finally:
            self.cosyvoice3_sampling_pending_tokens = None
        return MlxPendingDecode(
            lazy_tokens=lazy_tokens,
            req_ids=prev.req_ids,
            caches=prev.caches,
            lazy_logprobs=lazy_logprobs,
            logprob_spec=prev.logprob_spec,
            edit_rows=prev.edit_rows,
        )

    def prefill_finalize(self, pending: MlxPendingPrefill) -> int:
        token_id = super().prefill_finalize(pending)
        if 0 <= token_id < SPEECH_TOKEN_SIZE:
            self.record_seen_token(pending.req_id, token_id)
        else:
            pass
        return token_id

    def decode_batch_finalize(self, pending: MlxPendingDecode) -> list[int]:
        token_ids = super().decode_batch_finalize(pending)
        for req_id, token_id in zip(pending.req_ids, token_ids, strict=True):
            if 0 <= token_id < SPEECH_TOKEN_SIZE:
                self.record_seen_token(req_id, token_id)
            else:
                pass
        return token_ids

    def record_seen_token(self, req_id: str, token_id: int) -> None:
        seen = self.cosyvoice3_seen_masks[req_id] | (_SPEECH_IDS == token_id)
        mx.eval(seen)
        self.cosyvoice3_seen_masks[req_id] = seen
        recent = self.cosyvoice3_recent_tokens.setdefault(req_id, [])
        recent.append(token_id)
        del recent[:-10]

    def remove_request(self, req_id: str) -> None:
        super().remove_request(req_id)
        self.cosyvoice3_prompt_lengths.pop(req_id, None)
        self.cosyvoice3_min_lengths.pop(req_id, None)
        self.cosyvoice3_repetition_penalties.pop(req_id, None)
        self.cosyvoice3_seen_masks.pop(req_id, None)
        self.cosyvoice3_recent_tokens.pop(req_id, None)

    def clear(self) -> None:
        super().clear()
        self.cosyvoice3_sampling_pending_tokens = None
        self.cosyvoice3_prompt_lengths.clear()
        self.cosyvoice3_min_lengths.clear()
        self.cosyvoice3_repetition_penalties.clear()
        self.cosyvoice3_seen_masks.clear()
        self.cosyvoice3_recent_tokens.clear()


def make_fun_cosyvoice3_mlx_runner_class() -> type[MlxModelRunner]:
    """Build the runner after SGLang's MLX backend has been imported."""
    from sglang.srt.hardware_backend.mlx.model_runner import MlxModelRunner

    class FunCosyVoice3MlxRunner(FunCosyVoice3MlxModelRunner, MlxModelRunner):
        pass

    return FunCosyVoice3MlxRunner


__all__ = ["FunCosyVoice3MlxModelRunner", "make_fun_cosyvoice3_mlx_runner_class"]
