# SPDX-License-Identifier: Apache-2.0
"""Higgs TTS SGLang engine builder."""

from __future__ import annotations

import importlib
import logging
from collections.abc import Callable, Mapping
from typing import TYPE_CHECKING

from sglang.srt.server_args import ServerArgs

from sglang_omni.model_runner.model_worker import ModelWorker
from sglang_omni.models.higgs_tts import request_builders
from sglang_omni.models.higgs_tts import utils as higgs_utils
from sglang_omni.models.higgs_tts.request_builders import HiggsSGLangRequestData
from sglang_omni.models.higgs_tts.vocoder_scheduler import (
    DEFAULT_HIGGS_INITIAL_CHUNK_FRAMES,
    DEFAULT_HIGGS_STREAM_FOLLOWUP_STRIDE,
    DEFAULT_HIGGS_STREAM_STRIDE,
)
from sglang_omni.proto.request import StagePayload
from sglang_omni.scheduling.engine_factory import (
    GenerationDefaults,
    SchedulerExtras,
    TtsEngineBuilder,
)
from sglang_omni.scheduling.generation_batch_policy import (
    CudaGraphBackend,
    build_default_prefill_cuda_graph_bs,
)
from sglang_omni.scheduling.sglang_backend.output_processor import SGLangOutputProcessor
from sglang_omni.vendor.sglang.server_args import override_server_args

if TYPE_CHECKING:
    from sglang.srt.hardware_backend.mlx.tp_worker import MlxTpModelWorker

    from sglang_omni.models.higgs_tts.model import HiggsTTSModel
    from sglang_omni.models.higgs_tts.model_runner import HiggsTTSModelRunner
    from sglang_omni.scheduling.omni_scheduler import OmniScheduler
else:
    pass

logger = logging.getLogger(__name__)


class HiggsTtsEngineBuilder(TtsEngineBuilder[HiggsSGLangRequestData]):
    model_name = "Higgs TTS"
    context_length = 4096
    supports_breakable_prefill_cuda_graph = True

    def __init__(
        self,
        *,
        max_new_tokens: int | None,
        max_running_requests: int,
        cuda_graph_max_bs: int,
        enable_async_decode: bool,
        async_decode_min_batch_size: int,
        stream_stride: int = DEFAULT_HIGGS_STREAM_STRIDE,
        stream_followup_stride: int = DEFAULT_HIGGS_STREAM_FOLLOWUP_STRIDE,
        initial_chunk_frames: int = DEFAULT_HIGGS_INITIAL_CHUNK_FRAMES,
        prefill_coalesce_requests: int = 0,
        prefill_coalesce_wait_ms: float = 60.0,
        total_gpu_memory_fraction: float | None = None,
    ) -> None:
        if total_gpu_memory_fraction is not None and not (
            0.0 < total_gpu_memory_fraction < 1.0
        ):
            raise ValueError(
                "Higgs tts_engine total_gpu_memory_fraction must be in (0, 1): "
                "it drives sglang mem_fraction_static, which requires < 1"
            )
        else:
            pass
        self.max_new_tokens = max_new_tokens
        self.max_running_requests = max_running_requests
        self.cuda_graph_max_bs = cuda_graph_max_bs
        self.enable_async_decode = enable_async_decode
        self.async_decode_min_batch_size = async_decode_min_batch_size
        self.stream_stride = stream_stride
        self.stream_followup_stride = stream_followup_stride
        self.initial_chunk_frames = initial_chunk_frames
        self.prefill_coalesce_requests = prefill_coalesce_requests
        self.prefill_coalesce_wait_ms = prefill_coalesce_wait_ms
        self.total_gpu_memory_fraction = total_gpu_memory_fraction
        self.model: HiggsTTSModel | None = None

    def generation_defaults(
        self,
        *,
        dtype: str,
    ) -> GenerationDefaults:
        del dtype
        # note (luojiaxuan): Radix cache is namespaced per ref-audio via
        # Req.extra_key (set in build_sglang_higgs_request); shared -100
        # placeholder prefixes from different ref audios can't cross-contaminate
        # the KV tree.
        return {
            "max_running_requests": self.max_running_requests,
            "cuda_graph_max_bs": self.cuda_graph_max_bs,
            "disable_cuda_graph": False,
            "mem_fraction_static": (
                self.total_gpu_memory_fraction
                if self.total_gpu_memory_fraction is not None
                else 0.85
            ),
            "chunked_prefill_size": 8192,
            # Qualified capture budget; longer prefills run eager.
            "cuda_graph_backend_prefill": CudaGraphBackend.BREAKABLE,
            "cuda_graph_bs_prefill": build_default_prefill_cuda_graph_bs(512),
            "dtype": "bfloat16",
        }

    def adjust_overrides(self, overrides: Mapping[str, object]) -> None:
        # Note: (Jiaxin Deng) an explicit mem_fraction_static override (e.g.
        # --tts_engine.engine.mem_fraction_static) wins, but never silently.
        expected = self.total_gpu_memory_fraction
        if expected is None:
            return
        else:
            pass
        actual = overrides.get("mem_fraction_static")
        if actual is not None and abs(actual - expected) <= 1e-9:
            return
        else:
            pass
        logger.warning(
            "Higgs tts_engine mem_fraction_static=%s overrides the "
            "placement-validated total_gpu_memory_fraction=%s",
            actual,
            expected,
        )

    def customize_server_args(self, server_args: ServerArgs) -> None:
        override_server_args(
            server_args,
            "sglang_omni.higgs_tts.disable_overlap_schedule",
            disable_overlap_schedule=True,
        )

    def setup_model(
        self,
        *,
        model_worker: ModelWorker | MlxTpModelWorker,
        checkpoint_dir: str,
        device: str,
        gpu_id: int,
        server_args: ServerArgs,
    ) -> None:
        del checkpoint_dir, device, gpu_id, server_args
        self.model = model_worker.model_runner.model
        higgs_utils.truncate_rope_to_bf16(self.model)

    def get_model_buffer_bs(self, model: HiggsTTSModel) -> int | None:
        return model.sampler_pool_max_running_requests

    def make_model_runner(
        self,
        model_worker: ModelWorker | MlxTpModelWorker,
        output_proc: SGLangOutputProcessor,
    ) -> HiggsTTSModelRunner:
        model_runner_mod = importlib.import_module(
            "sglang_omni.models.higgs_tts.model_runner"
        )

        return model_runner_mod.HiggsTTSModelRunner(model_worker, output_proc)

    def make_adapters(self, model: object) -> tuple[
        Callable[[StagePayload], HiggsSGLangRequestData],
        Callable[[HiggsSGLangRequestData], StagePayload],
    ]:
        del model
        return request_builders.make_higgs_scheduler_adapters(
            max_new_tokens_cap=self.max_new_tokens,
            stream_stride=self.stream_stride,
            stream_followup_stride=self.stream_followup_stride,
            initial_chunk_frames=self.initial_chunk_frames,
        )

    def make_abort_callback(self) -> Callable[[str], None]:
        assert self.model is not None
        return self.model.reset_request

    def make_request_finished_callback(self) -> Callable[[str], None]:
        assert self.model is not None
        return self.model.reset_request

    def extra_scheduler_kwargs(self) -> SchedulerExtras[HiggsSGLangRequestData]:
        return {
            "enable_async_decode": self.enable_async_decode,
            "async_decode_min_batch_size": self.async_decode_min_batch_size,
            "prefill_coalesce_requests": self.prefill_coalesce_requests,
            "prefill_coalesce_wait_ms": self.prefill_coalesce_wait_ms,
        }

    def post_scheduler_setup(
        self,
        scheduler: OmniScheduler[HiggsSGLangRequestData],
        model_runner: HiggsTTSModelRunner,
    ) -> None:
        model_runner.set_stream_outbox(scheduler.outbox)
