# SPDX-License-Identifier: Apache-2.0
"""Typed references to data-plane buffers carried by control messages."""

from __future__ import annotations

from collections.abc import Mapping
from enum import Enum
from typing import Annotated, TypeVar

import msgspec

DataRefValueT = TypeVar("DataRefValueT")


class TransportKind(str, Enum):
    LOCAL_OBJECT = "local_object"
    CUDA_IPC = "cuda_ipc"
    SHM = "shm"
    MOONCAKE = "mooncake"


class DataKind(str, Enum):
    STAGE_PAYLOAD = "stage_payload"
    STREAM_CHUNK = "stream_chunk"
    STREAM_METADATA_TENSOR = "stream_metadata_tensor"
    KV_PAGES = "kv_pages"
    WEIGHT_BUCKET = "weight_bucket"
    MOE_EXPERT_PAYLOAD = "moe_expert_payload"


class DataLayout(str, Enum):
    PACKED_TENSORS = "packed_tensors"
    RAW_TENSOR = "raw_tensor"
    PAGED = "paged"
    BUCKETED = "bucketed"
    SCATTER = "scatter"


class TensorMeta(msgspec.Struct, frozen=True):
    path: str
    shape: tuple[int, ...]
    dtype: str
    device: str
    offset: int
    size: int

    def to_dict(self) -> dict[str, str | list[int] | int]:
        return {
            "path": self.path,
            "shape": list(self.shape),
            "dtype": self.dtype,
            "device": self.device,
            "offset": self.offset,
            "size": self.size,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "TensorMeta":
        return cls(
            path=required(value, "path", str),
            shape=int_tuple(value, "shape"),
            dtype=required(value, "dtype", str),
            device=required(value, "device", str),
            offset=required(value, "offset", int),
            size=required(value, "size", int),
        )


class BackendRef(msgspec.Struct, frozen=True):
    transport: TransportKind
    info: dict[str, Annotated[object, msgspec.Meta(extra_json_schema={"anyOf": [{}]})]]
    length: int

    @classmethod
    def from_relay_info(
        cls, *, transport: TransportKind, relay_info: dict[str, object]
    ) -> "BackendRef":
        transfer_info = required(relay_info, "transfer_info", dict)
        return cls(
            transport=transport,
            info=relay_info,
            length=required(transfer_info, "size", int),
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "transport": self.transport.value,
            "info": self.info,
            "length": self.length,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "BackendRef":
        return cls(
            transport=TransportKind(required(value, "transport", str)),
            info=required(value, "info", dict),
            length=required(value, "length", int),
        )


class MetadataTensorRef(msgspec.Struct, frozen=True):
    path: str
    ref: "DataRef"

    def to_dict(self) -> dict[str, object]:
        return {"path": self.path, "ref": self.ref.to_dict()}

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "MetadataTensorRef":
        return cls(
            path=required(value, "path", str),
            ref=DataRef.from_dict(required(value, "ref", dict)),
        )


class DataRef(msgspec.Struct, frozen=True):
    """Control-plane pointer to one data-plane object."""

    version: int
    kind: DataKind
    object_id: str
    transport: TransportKind
    layout: DataLayout
    buffer: BackendRef
    header: str | None = None
    tensors: tuple[TensorMeta, ...] = ()
    shape: tuple[int, ...] | None = None
    dtype: str | None = None
    device: str | None = None
    offset: int | None = None
    metadata: dict[str, object] | None = None
    metadata_tensors: tuple[MetadataTensorRef, ...] = ()

    def to_dict(self) -> dict[str, object]:
        value: dict[str, object] = {
            "_type": "DataRef",
            "version": self.version,
            "kind": self.kind.value,
            "object_id": self.object_id,
            "transport": self.transport.value,
            "layout": self.layout.value,
            "buffer": self.buffer.to_dict(),
            "tensors": [tensor.to_dict() for tensor in self.tensors],
            "metadata_tensors": [
                tensor_ref.to_dict() for tensor_ref in self.metadata_tensors
            ],
        }
        if self.header is not None:
            value["header"] = self.header
        else:
            pass
        if self.shape is not None:
            value["shape"] = list(self.shape)
        else:
            pass
        if self.dtype is not None:
            value["dtype"] = self.dtype
        else:
            pass
        if self.device is not None:
            value["device"] = self.device
        else:
            pass
        if self.offset is not None:
            value["offset"] = self.offset
        else:
            pass
        if self.metadata is not None:
            value["metadata"] = self.metadata
        else:
            pass
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, object]) -> "DataRef":
        if required(value, "_type", str) != "DataRef":
            raise ValueError("data_ref must have _type='DataRef'")
        else:
            pass
        version = required(value, "version", int)
        if version != 1:
            raise ValueError(f"unsupported DataRef version {version}")
        else:
            pass
        return cls(
            version=version,
            kind=DataKind(required(value, "kind", str)),
            object_id=required(value, "object_id", str),
            transport=TransportKind(required(value, "transport", str)),
            layout=DataLayout(required(value, "layout", str)),
            buffer=BackendRef.from_dict(required(value, "buffer", dict)),
            header=optional(value, "header", str),
            tensors=tuple(
                TensorMeta.from_dict(item) for item in required(value, "tensors", list)
            ),
            shape=int_tuple(value, "shape") if "shape" in value else None,
            dtype=optional(value, "dtype", str),
            device=optional(value, "device", str),
            offset=required(value, "offset", int) if "offset" in value else None,
            metadata=(
                required(value, "metadata", dict) if "metadata" in value else None
            ),
            metadata_tensors=tuple(
                MetadataTensorRef.from_dict(item)
                for item in required(value, "metadata_tensors", list)
            ),
        )


def required(
    value: Mapping[str, object], key: str, expected: type[DataRefValueT]
) -> DataRefValueT:
    item = value[key]
    if type(item) is not expected:
        raise TypeError(f"{key} must be {expected.__name__}, got {type(item).__name__}")
    else:
        pass
    return item


def optional(
    value: Mapping[str, object], key: str, expected: type[DataRefValueT]
) -> DataRefValueT | None:
    item = value.get(key)
    if item is None:
        return None
    else:
        pass
    if type(item) is not expected:
        raise TypeError(
            f"{key} must be {expected.__name__} or None, got {type(item).__name__}"
        )
    else:
        pass
    return item


def int_tuple(value: Mapping[str, object], key: str) -> tuple[int, ...]:
    items = required(value, key, list)
    if not all(type(item) is int for item in items):
        raise TypeError(f"{key} must be list[int]")
    else:
        pass
    return tuple(items)
