# SPDX-License-Identifier: Apache-2.0
"""dots.tts SGLang engine builder."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TYPE_CHECKING

from sglang_omni.model_runner.model_worker import ModelWorker
from sglang_omni.proto.request import StagePayload
from sglang_omni.scheduling.engine_factory import (
    GenerationDefaults,
    SchedulerExtras,
    TtsEngineBuilder,
)

if TYPE_CHECKING:
    from sglang.srt.hardware_backend.mlx.tp_worker import MlxTpModelWorker
    from sglang.srt.server_args import ServerArgs

    from sglang_omni.models.dots_tts.model_runner import DotsTTSModelRunner
    from sglang_omni.models.dots_tts.request_builders import DotsTTSSGLangRequestData
    from sglang_omni.models.dots_tts.sglang_model import DotsTTSSGLangModel
    from sglang_omni.models.dots_tts.tail import DotsTtsAcousticTail
    from sglang_omni.scheduling.sglang_backend.output_processor import (
        SGLangOutputProcessor,
    )
else:
    pass


logger = logging.getLogger(__name__)


class DotsTTSEngineBuilder(TtsEngineBuilder["DotsTTSSGLangRequestData"]):
    model_name = "dots.tts"
    context_length = 2048

    def __init__(
        self,
        *,
        optimize: bool = True,
        num_steps: int = 4,
        max_audio_patches: int = 500,
        max_running_requests: int = 16,
    ) -> None:
        from sglang_omni.models.dots_tts.hf_config import DOTS_TTS_MODEL_ARCH_OVERRIDE

        self.model_arch_override = DOTS_TTS_MODEL_ARCH_OVERRIDE
        self.optimize = bool(optimize)
        self.num_steps = int(num_steps)
        self.max_audio_patches = int(max_audio_patches)
        self.max_running_requests = int(max_running_requests)
        if min(self.num_steps, self.max_audio_patches, self.max_running_requests) <= 0:
            raise ValueError("dots.tts batching limits must be positive")
        else:
            pass
        self.model_runner: DotsTTSModelRunner | None = None
        self.acoustic_tail: DotsTtsAcousticTail | None = None

    def pre_infra_setup(self, checkpoint_dir: str) -> None:
        del checkpoint_dir
        from sglang_omni.models.dots_tts.hf_config import register_dots_tts_hf_config

        register_dots_tts_hf_config()

    def customize_server_args(self, server_args: ServerArgs | None) -> None:
        from sglang.srt.arg_groups.model_override_base import resolved_view

        cfg = resolved_view(server_args)
        # The compiled DiT path only serves max_running_requests=1; the batched
        # tail is eager, so skip the process-global compile policy otherwise.
        # The policy must exist before SGLang builds the model; applying it in
        # setup_model nests Dynamo under FX.
        if self.optimize and int(cfg.max_running_requests) == 1:
            from sglang_omni.models.dots_tts.stages import configure_optimized_kernels

            configure_optimized_kernels()
        else:
            pass

    def generation_defaults(self, *, dtype: str) -> GenerationDefaults:
        return {
            "disable_cuda_graph": True,
            "disable_overlap_schedule": True,
            "disable_radix_cache": True,
            "enable_torch_compile": False,
            "max_running_requests": self.max_running_requests,
            "chunked_prefill_size": 0,
            "mem_fraction_static": 0.20,
            "dtype": dtype,
            "trust_remote_code": False,
        }

    def adjust_overrides(self, overrides: dict[str, object]) -> None:
        if int(overrides.get("tp_size", 1)) != 1:
            raise ValueError("dots.tts base support does not implement TP")
        else:
            pass
        requested = int(
            overrides.get("max_running_requests", self.max_running_requests)
        )
        if requested <= 0:
            raise ValueError("dots.tts max_running_requests must be positive")
        else:
            pass
        self.max_running_requests = requested
        overrides["disable_radix_cache"] = True
        overrides["chunked_prefill_size"] = 0
        if bool(overrides.get("enable_torch_compile", False)):
            raise ValueError(
                "dots.tts uses its DiT compile path; SGLang backbone compile is disabled"
            )
        else:
            pass
        if not bool(overrides.get("disable_cuda_graph", True)):
            # note (luojiaxuan): the decode graph must be captured with hidden states (FULL);
            # its can_run gate requires an exact hidden-mode match with the
            # acoustic tail's per-step request.
            overrides["enable_return_hidden_states"] = True
        else:
            pass

    def setup_model(
        self,
        *,
        model_worker: ModelWorker | MlxTpModelWorker,
        checkpoint_dir: str,
        device: str,
        gpu_id: int,
        server_args: ServerArgs,
    ) -> None:
        del checkpoint_dir, device, gpu_id
        from sglang.srt.runtime_context import get_exec, get_schedule

        model = model_worker.model_runner.model
        max_running_requests = int(get_schedule().max_running_requests)
        if not bool(get_exec().graph.disable_cuda_graph):
            from sglang_omni.scheduling.generation_batch_policy import (
                get_decode_cuda_graph_max_bs,
            )

            # note (luojiaxuan): installed before init_cuda_graphs so capture bakes the buffer
            # address into the decode graph. Generously sized: rows are tiny
            # (hidden_size elements) and capture may pad above
            # max_running_requests.
            model.enable_graph_feedback(
                max(
                    max_running_requests,
                    int(get_decode_cuda_graph_max_bs(server_args) or 0),
                    256,
                )
            )
        else:
            pass
        model.flow.optimize = self.optimize and max_running_requests == 1
        model.eval()
        if max_running_requests > 1:
            model.flow.init_batched_tail(
                num_slots=max_running_requests,
                nfe=self.num_steps,
                max_audio_patches=self.max_audio_patches,
                optimize=self.optimize,
            )
            self.acoustic_tail = model.flow.batched_tail
        else:
            pass
        if max_running_requests == 1:
            tail_backend = (
                "compiled single-request DiT/semantic encoder"
                if model.flow.optimize
                else "eager single-request DiT/semantic encoder"
            )
        else:
            tail_backend = model.flow.batched_tail.backend
        logger.info(
            "dots.tts latent engine backend: %s (optimize=%s, "
            "max_running_requests=%d, num_steps=%d)",
            tail_backend,
            self.optimize,
            max_running_requests,
            self.num_steps,
        )
        logger.info(
            "dots.tts backbone decode: %s",
            (
                "SGLang CUDA graph with model-owned feedback buffer"
                if not bool(get_exec().graph.disable_cuda_graph)
                else "eager"
            ),
        )

    def make_model_runner(
        self,
        model_worker: ModelWorker | MlxTpModelWorker,
        output_proc: SGLangOutputProcessor,
    ) -> DotsTTSModelRunner:
        from sglang_omni.models.dots_tts.model_runner import DotsTTSModelRunner

        self.model_runner = DotsTTSModelRunner(model_worker, output_proc)
        return self.model_runner

    def make_adapters(self, model: DotsTTSSGLangModel | None) -> tuple[
        Callable[[StagePayload], DotsTTSSGLangRequestData],
        Callable[[DotsTTSSGLangRequestData], StagePayload],
    ]:
        from sglang_omni.models.dots_tts.request_builders import (
            apply_latent_result,
            build_sglang_dots_tts_request,
        )

        def _build_request(payload: StagePayload) -> DotsTTSSGLangRequestData:
            data = build_sglang_dots_tts_request(payload)
            model.flow.validate_request(
                num_steps=data.state.num_steps,
                ode_method=data.state.ode_method,
                prompt_patch_count=int(data.prompt_span_positions.numel()),
                total_span_count=int(data.span_positions.numel()),
            )
            return data

        return _build_request, apply_latent_result

    def make_abort_callback(self) -> Callable[[str], None]:
        assert self.model_runner is not None
        return self.model_runner.reset_request

    def extra_scheduler_callbacks(self) -> dict[str, Callable[[], None]]:
        if self.acoustic_tail is None:
            return {}
        else:
            pass
        return {"shutdown_callback": self.acoustic_tail.log_graph_counters}

    def extra_scheduler_kwargs(self) -> SchedulerExtras[DotsTTSSGLangRequestData]:
        from sglang_omni.models.dots_tts.request_builders import build_stream_output

        return {
            "stream_output_builder": build_stream_output,
            "enable_async_decode": False,
        }


__all__ = ["DotsTTSEngineBuilder"]
