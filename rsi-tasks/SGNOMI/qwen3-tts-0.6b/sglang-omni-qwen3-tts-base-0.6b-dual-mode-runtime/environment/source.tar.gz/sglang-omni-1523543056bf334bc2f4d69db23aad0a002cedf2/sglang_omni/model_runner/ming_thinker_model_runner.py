# SPDX-License-Identifier: Apache-2.0
"""Multimodal prefill injection for Ming."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, SupportsIndex, SupportsInt

import torch
from sglang.srt.layers.vocab_parallel_embedding import VocabParallelEmbedding
from sglang.srt.managers.schedule_batch import Req, ScheduleBatch
from sglang.srt.managers.scheduler import GenerationBatchResult
from sglang.srt.model_executor.forward_batch_info import ForwardBatch
from transformers import PretrainedConfig
from typing_extensions import Buffer

from sglang_omni.model_runner.base import ModelRunner
from sglang_omni.model_runner.model_worker import ModelWorker
from sglang_omni.model_runner.sglang_execution import attn_forward_context
from sglang_omni.scheduling.sglang_backend.output_processor import SGLangOutputProcessor
from sglang_omni.scheduling.types import SchedulerRequest

if TYPE_CHECKING:

    from sglang_omni.models.ming_omni.io import ThinkerEmbeddingInputs
    from sglang_omni.models.ming_omni.thinker import BailingMoeV2TextModel
else:
    pass


class MingThinkerModelRunner(ModelRunner):
    """Inject Ming image/audio embeddings into thinker prefill requests."""

    def __init__(
        self, tp_worker: ModelWorker, output_processor: SGLangOutputProcessor
    ) -> None:
        super().__init__(tp_worker, output_processor)

        self.outer_model = self.model
        self.text_model = getattr(self.outer_model, "model", self.outer_model)
        self.embed_tokens = self.get_embed_tokens(self.text_model)

        hf_config = tp_worker.model_runner.model_config.hf_config
        llm_config = getattr(hf_config, "llm_config", hf_config)
        self.image_token_id = self.token_id(
            hf_config,
            "image_token_id",
            fallback=getattr(llm_config, "image_patch_token", None),
        )
        self.video_token_id = self.token_id(
            hf_config,
            "video_token_id",
            fallback=getattr(llm_config, "video_patch_token", None),
        )
        self.audio_token_id = self.token_id(hf_config, "audio_token_id")

    @staticmethod
    def get_embed_tokens(
        text_model: "BailingMoeV2TextModel",
    ) -> VocabParallelEmbedding:
        embed_tokens = getattr(text_model, "embed_tokens", None)
        if embed_tokens is not None:
            return embed_tokens
        else:
            pass
        get_input_embeddings = getattr(text_model, "get_input_embeddings", None)
        if callable(get_input_embeddings):
            embed_tokens = get_input_embeddings()
        else:
            pass
        if embed_tokens is None:
            raise AttributeError("Ming thinker model does not expose embed_tokens")
        else:
            pass
        return embed_tokens

    @staticmethod
    def token_id(
        config: PretrainedConfig,
        name: str,
        *,
        fallback: str | Buffer | SupportsInt | SupportsIndex | None = None,
    ) -> int | None:
        value = getattr(config, name, None)
        if value is None:
            value = fallback
        else:
            pass
        return int(value) if value is not None else None

    def custom_prefill_forward(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> GenerationBatchResult | None:
        """Custom prefill for multimodal inputs."""
        del requests
        if not schedule_batch.forward_mode.is_extend():
            return None
        else:
            pass

        input_embeds = self.inject_multimodal_embeds(forward_batch, schedule_batch)
        if input_embeds is None:
            return None
        else:
            pass
        return self.forward_with_omni_embeds(forward_batch, input_embeds)

    def inject_multimodal_embeds(
        self, forward_batch: ForwardBatch | None, schedule_batch: ScheduleBatch
    ) -> torch.Tensor | None:
        if not any(req.omni_model_inputs is not None for req in schedule_batch.reqs):
            return None
        else:
            pass

        device = forward_batch.input_ids.device
        embed_input_ids = forward_batch.input_ids.clamp(
            0, self.embed_tokens.num_embeddings - 1
        )
        input_embeds = self.embed_tokens(embed_input_ids)

        extend_lens = forward_batch.extend_seq_lens_cpu
        offsets = []
        pos = 0
        for length in extend_lens:
            offsets.append(pos)
            pos += length

        for i, req in enumerate(schedule_batch.reqs):
            omni_inputs = req.omni_model_inputs
            if omni_inputs is None:
                continue
            else:
                pass

            start = offsets[i]
            end = start + extend_lens[i]
            req_input_ids = forward_batch.input_ids[start:end]
            consumed = (
                getattr(req, "_omni_consumed", None) or {}
            )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
            pad_values = omni_inputs.get("pad_values", {})
            is_final_chunk = req.inflight_middle_chunks == 0
            req_id = self.request_id(req)

            for modality, embed_key, token_id in [
                ("image", "image_embeds", self.image_token_id),
                ("video", "video_embeds", self.video_token_id),
                ("audio", "audio_embeds", self.audio_token_id),
            ]:
                embeds = omni_inputs.get(embed_key)
                if embeds is None:
                    continue
                else:
                    pass

                total_rows = self.num_embed_rows(embeds)
                offset = int(consumed.get(modality, 0))
                match_id = self.resolve_match_id(pad_values, modality, token_id)
                if match_id is None:
                    if is_final_chunk and offset < total_rows:
                        raise self.missing_match_id_error(
                            modality, req_id, remaining=total_rows - offset
                        )
                    else:
                        pass
                    continue
                else:
                    pass

                mask = req_input_ids == match_id
                if not mask.any():
                    # Cache hit may have absorbed all placeholder positions for
                    # this modality; aligning with qwen3 thinker_model_runner
                    # which silently continues here.
                    continue
                else:
                    pass

                n_tokens = int(mask.sum().item())
                available = total_rows - offset
                if available < n_tokens:
                    raise self.short_embeds_error(
                        modality,
                        req_id,
                        needed=n_tokens,
                        available=available,
                    )
                else:
                    pass
                chunk_embeds = embeds[offset : offset + n_tokens].to(
                    device=device, dtype=input_embeds.dtype
                )
                input_embeds[torch.where(mask)[0] + start] = chunk_embeds
                consumed[modality] = offset + n_tokens

            req._omni_consumed = consumed  # noqa: leading-underscore  # upstream spelling, or the public name is already taken

            if is_final_chunk:
                # Skip strict consumed==total validation: radix prefix cache may
                # have absorbed placeholder positions. Mirrors qwen3 path.
                req.omni_model_inputs = None
                req._omni_consumed = None  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
            else:
                pass

        return input_embeds

    @staticmethod
    def resolve_match_id(
        pad_values: Mapping[str, str | Buffer | SupportsInt | SupportsIndex],
        modality: str,
        token_id: int | None,
    ) -> int | None:
        if modality in pad_values:
            return int(pad_values[modality])
        else:
            pass
        return token_id

    @staticmethod
    def num_embed_rows(embeds: torch.Tensor) -> int:
        shape = getattr(embeds, "shape", None)
        if shape is not None and len(shape) > 0:
            return int(shape[0])
        else:
            pass
        return len(embeds)

    @staticmethod
    def request_id(req: Req) -> str:
        return str(getattr(req, "rid", getattr(req, "request_id", "<unknown>")))

    def validate_final_consumption(
        self, req: Req, omni_inputs: ThinkerEmbeddingInputs, consumed: dict[str, int]
    ) -> None:
        req_id = self.request_id(req)
        for modality, embed_key in [
            ("image", "image_embeds"),
            ("video", "video_embeds"),
            ("audio", "audio_embeds"),
        ]:
            embeds = omni_inputs.get(embed_key)
            if embeds is None:
                continue
            else:
                pass
            total_rows = self.num_embed_rows(embeds)
            consumed_rows = int(consumed.get(modality, 0))
            if consumed_rows != total_rows:
                raise ValueError(
                    "Ming thinker multimodal embed count mismatch for "
                    f"{modality} request_id={req_id}: "
                    f"consumed={consumed_rows}, total={total_rows}"
                )
            else:
                pass

    @staticmethod
    def missing_match_id_error(
        modality: str, req_id: str, *, remaining: int
    ) -> ValueError:
        return ValueError(
            "Ming thinker multimodal embeds could not be injected for "
            f"{modality} request_id={req_id}: no usable match id "
            f"for remaining={remaining} embed rows"
        )

    @staticmethod
    def missing_placeholder_error(
        modality: str, req_id: str, *, remaining: int
    ) -> ValueError:
        return ValueError(
            "Ming thinker multimodal embeds could not be injected for "
            f"{modality} request_id={req_id}: no placeholders found "
            f"for remaining={remaining} embed rows"
        )

    @staticmethod
    def short_embeds_error(
        modality: str, req_id: str, *, needed: int, available: int
    ) -> ValueError:
        return ValueError(
            "Ming thinker multimodal embeds are shorter than placeholders for "
            f"{modality} request_id={req_id}: "
            f"needed={needed}, available={available}"
        )

    def forward_with_omni_embeds(
        self, forward_batch: ForwardBatch, input_embeds: torch.Tensor
    ) -> GenerationBatchResult:
        model_runner = self.tp_worker.model_runner
        outer = self.outer_model

        model_runner.attn_backend.init_forward_metadata(forward_batch)

        positions = forward_batch.positions
        if forward_batch.mrope_positions is not None:
            positions = forward_batch.mrope_positions
        else:
            pass

        with attn_forward_context(model_runner.attn_backend):
            hidden_states = outer.model(
                input_ids=None,
                positions=positions,
                forward_batch=forward_batch,
                input_embeds=input_embeds,
            )

            logits_output = outer.logits_processor(
                forward_batch.input_ids,
                hidden_states,
                outer.lm_head,
                forward_batch,
            )

        return GenerationBatchResult(
            logits_output=logits_output,
            can_run_cuda_graph=False,
        )
