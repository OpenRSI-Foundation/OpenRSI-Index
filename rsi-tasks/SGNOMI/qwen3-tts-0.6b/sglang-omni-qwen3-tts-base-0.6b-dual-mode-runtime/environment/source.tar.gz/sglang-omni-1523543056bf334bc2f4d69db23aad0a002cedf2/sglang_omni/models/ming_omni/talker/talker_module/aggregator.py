# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# GLIDE: https://github.com/openai/glide-text2im
# MAE: https://github.com/facebookresearch/mae/blob/main/models_mae.py
# --------------------------------------------------------

import torch
import torch.nn as nn

from .execution import TalkerExecutionConfig
from .modules import DiTBlock, FinalLayer, RMSNorm
from .rotary import build_rotary_embedding, get_rotary_inputs, validate_rotary_config


class Aggregator(nn.Module):
    """
    Diffusion model with a Transformer backbone.
    """

    def __init__(
        self,
        in_channels=64,
        hidden_size=1152,
        depth=28,
        num_heads=16,
        mlp_ratio=4.0,
        llm_input_dim=896,
        *,
        execution_config: TalkerExecutionConfig | None = None,
        **kwargs,
    ):
        super().__init__()
        execution_config = execution_config or TalkerExecutionConfig()
        validate_rotary_config(
            execution_config.rope_kernel,
            num_heads=num_heads,
            qk_norm=kwargs.get("qk_norm"),
            pe_attn_head=kwargs.get("pe_attn_head"),
        )
        if execution_config.attn_backend is not None:
            kwargs["attn_backend"] = execution_config.attn_backend
        else:
            pass
        norm_layer = execution_config.norm_layer or RMSNorm

        self.in_channels = in_channels
        self.out_channels = in_channels
        self.num_heads = num_heads

        self.word_embedder = nn.Embedding(1, hidden_size)
        self.x_embedder = nn.Linear(in_channels, hidden_size)
        self.hidden_size = hidden_size

        self.rotary_embed = build_rotary_embedding(
            hidden_size // num_heads,
            kernel=execution_config.rope_kernel,
            seq_len=execution_config.rope_seq_len,
            max_batch_size=execution_config.rope_max_batch_size,
        )

        self.blocks = nn.ModuleList(
            [
                DiTBlock(
                    hidden_size,
                    num_heads,
                    mlp_ratio=mlp_ratio,
                    norm_layer=norm_layer,
                    qkv_layer=execution_config.qkv_layer,
                    **kwargs,
                )
                for _ in range(depth)
            ]
        )
        self.final_layer = FinalLayer(
            hidden_size,
            llm_input_dim,
            norm_layer=norm_layer,
        )
        self.initialize_weights()

    def initialize_weights(self):
        # Initialize transformer layers:
        def _basic_init(module):
            if isinstance(module, nn.Linear):
                torch.nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
                else:
                    pass
            else:
                pass

        self.apply(_basic_init)

        # Initialize patch_embed like nn.Linear (instead of nn.Conv2d):
        w_x = self.x_embedder.weight.data
        nn.init.xavier_uniform_(w_x.view([w_x.shape[0], -1]))
        nn.init.constant_(self.x_embedder.bias, 0)

        # Initialize word embedding table:
        nn.init.normal_(self.word_embedder.weight, std=0.02)

        # Zero-out output layers:
        nn.init.constant_(self.final_layer.linear.weight, 0)
        nn.init.constant_(self.final_layer.linear.bias, 0)

    def forward(self, x, mask=None):
        """
        Forward pass of DiT.
        x: (N, C, H, W) tensor of spatial inputs (images or latent representations of images)
        t: (N,) tensor of diffusion timesteps
        y: (N,) tensor of class labels
        """
        x = self.x_embedder(x)
        cls_embed = self.word_embedder(
            torch.zeros((x.shape[0], 1), dtype=torch.long, device=x.device)
        )  # cls token for bidirectional attention
        x = torch.cat([cls_embed, x], dim=1)

        rope = get_rotary_inputs(self.rotary_embed, x.shape[0], x.shape[1])
        if mask is not None:
            mask_pad = mask.clone().detach()[:, :1]
            mask = torch.cat([mask_pad, mask], dim=-1)
        else:
            pass
        for block in self.blocks:
            x = block(x, mask, rope)  # (N, T, D)
        x = self.final_layer(x)  # (N, T, patch_size ** 2 * out_channels)
        x = x[:, :1, :]
        return x


class PoolAgg(nn.Module):
    def __init__(self, in_channels=64, llm_input_dim=896):
        super().__init__()
        self.final_layer = FinalLayer(in_channels, llm_input_dim)
        self.initialize_weights()

    def initialize_weights(self):
        # Zero-out output layers:
        nn.init.constant_(self.final_layer.linear.weight, 0)
        nn.init.constant_(self.final_layer.linear.bias, 0)

    def forward(self, x, mask=None):
        x = self.final_layer(x)
        x = x.mean(dim=1, keepdim=True)
        return x


class AggLinear(nn.Module):
    def __init__(self, in_channels=64, llm_input_dim=896):
        super().__init__()
        self.fc = nn.Linear(in_channels, llm_input_dim)
        self.initialize_weights()

    def initialize_weights(self):
        # Zero-out output layers:
        nn.init.constant_(self.fc.weight, 0)
        nn.init.constant_(self.fc.bias, 0)

    def forward(self, x, mask=None):
        x = x.mean(dim=1, keepdim=True)
        x = self.fc(x)
        return x
