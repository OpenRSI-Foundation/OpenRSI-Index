# SPDX-License-Identifier: Apache-2.0
"""Talker executor for Ming-Omni.

Wraps MingOmniTalker as a pipeline stage. The talker
receives decoded text from the thinker and independently generates speech audio
using its own internal LLM + CFM + DiT + AudioVAE pipeline.

The talker is a self-contained TTS system that:
1. Tokenizes input text with its own tokenizer
2. Runs its own Qwen2 LLM with StaticCache + device graphs
3. Uses CFM (Conditional Flow Matching) + DiT for diffusion-based audio synthesis
4. Decodes audio latents to waveform via AudioVAE
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from pathlib import Path

import torch

from sglang_omni.models.ming_omni.pipeline.usage import build_text_usage
from sglang_omni.proto import StagePayload

logger = logging.getLogger(__name__)

DEFAULT_VOICE = "DB30"


def build_talker_usage(payload: StagePayload) -> dict[str, int]:
    data = payload.data if isinstance(payload.data, dict) else {}
    return build_text_usage(data)


class MingTalkerExecutor:
    """Executor that wraps MingOmniTalker for speech generation."""

    def __init__(
        self,
        model_path: str,
        talker_model_path: str | None = None,
        device: str = "cuda",
        voice: str = DEFAULT_VOICE,
    ):
        self.model_path = model_path
        self.talker_model_path = talker_model_path or str(Path(model_path) / "talker")
        self.device = device
        self.voice = voice
        self.results: asyncio.Queue[StagePayload] = asyncio.Queue()
        self.aborted: set[str] = set()

        self.talker = None
        self.vae = None
        self.thinker_tokenizer = None

    async def start(self) -> None:
        """Initialize the talker model and AudioVAE."""
        logger.info("Loading Ming talker from %s", self.talker_model_path)
        await asyncio.to_thread(self.load_models)
        logger.info("Ming talker loaded and initialized")

    def load_models(self) -> None:
        """Load talker model and VAE (runs in thread pool)."""
        from transformers import AutoTokenizer

        from sglang_omni.models.ming_omni.talker import MingOmniTalker, SpkembExtractor
        from sglang_omni.models.ming_omni.talker.audio_vae.modeling_audio_vae import (
            AudioVAE,
        )

        logger.info(
            "[TALKER] Loading MingOmniTalker from %s (device=%s)",
            self.talker_model_path,
            self.device,
        )

        # 1-3. Load config, create the model, and stream weights before moving it
        t0 = time.time()
        self.talker = MingOmniTalker.from_pretrained(
            self.talker_model_path, device=self.device
        )
        logger.info("[TALKER] MingOmniTalker loaded in %.1fs", time.time() - t0)

        # 4. Load tokenizer externally
        tokenizer = AutoTokenizer.from_pretrained(
            str(Path(self.talker_model_path) / "llm")
        )
        self.talker.set_tokenizer(tokenizer)

        # 5. Load voice presets
        voice_json_path = os.path.join(
            self.talker_model_path, "data", "voice_name.json"
        )
        if os.path.exists(voice_json_path):
            with open(voice_json_path, "r") as f:
                voice_dict = json.load(f)
            self.validate_voice_presets(
                voice_dict, voice_json_path, self.talker_model_path
            )
            self.talker.set_voice_presets(voice_dict)
        elif self.voice is not None:
            raise FileNotFoundError(
                f"[TALKER] voice_name.json not found at {voice_json_path}; "
                f"default voice {self.voice!r} cannot be resolved"
            )
        else:
            logger.info(
                "[TALKER] no voice_name.json at %s; presets disabled", voice_json_path
            )

        # 6. Load speaker embedding extractor (optional)
        campplus_path = os.path.join(self.talker_model_path, "campplus.onnx")
        try:
            extractor = SpkembExtractor(campplus_path)
            self.talker.set_spkemb_extractor(extractor)
        except (ImportError, Exception) as e:
            logger.warning("[TALKER] SpkembExtractor not available: %s", e)

        # 7. Load text normalizer (optional)
        try:
            from talker_tn.talker_tn import TalkerTN

            self.talker.set_normalizer(TalkerTN())
        except ImportError:
            logger.warning(
                "[TALKER] TalkerTN (pynini) not available — using identity normalizer"
            )

        # 8. Load AudioVAE
        vae_path = str(Path(self.talker_model_path) / "vae")
        if Path(vae_path).exists():
            t0v = time.time()
            self.vae = AudioVAE.from_pretrained(vae_path, dtype=torch.bfloat16)
            self.vae.to(self.device)
            self.vae.eval()
            logger.info("[TALKER] AudioVAE loaded in %.1fs", time.time() - t0v)
        else:
            logger.warning("[TALKER] AudioVAE not found at %s", vae_path)

        # 9. Load thinker tokenizer for decoding output_ids
        try:
            from sglang_omni.models.ming_omni.components.common import (
                load_ming_tokenizer,
            )

            self.thinker_tokenizer = load_ming_tokenizer(self.model_path)
            logger.info(
                "[TALKER] Thinker tokenizer loaded: %s",
                type(self.thinker_tokenizer).__name__,
            )
        except Exception as e:
            logger.warning("[TALKER] Could not load thinker tokenizer: %s", e)

        # 10. Initialize device graphs
        logger.info("[TALKER] Initializing device graphs...")
        t0g = time.time()
        self.talker.initial_graph()
        logger.info("[TALKER] Device graphs initialized in %.1fs", time.time() - t0g)

    async def add_request(self, payload: StagePayload) -> None:
        """Process a TTS request."""
        request_id = payload.request_id
        if request_id in self.aborted:
            return
        else:
            pass
        if not self.should_generate_audio(payload):
            logger.info(
                "[TALKER] Skipping TTS for request %s; output_modalities=%s",
                request_id,
                self.output_modalities(payload),
            )
            await self.results.put(self.build_empty_audio_result(payload))
            return
        else:
            pass

        text = self.extract_text(payload)
        logger.info(
            "[TALKER] Extracted text (len=%d): %r",
            len(text) if text else 0,
            text[:200] if text else "",
        )
        if not text:
            result = StagePayload(
                request_id=request_id,
                request=payload.request,
                data={
                    "audio_waveform": None,
                    "sample_rate": 44100,
                    "duration": 0.0,
                    "modality": "audio",
                    "usage": build_talker_usage(payload),
                },
            )
            await self.results.put(result)
            return
        else:
            pass

        t0 = time.time()
        logger.info("[TALKER] Starting TTS generation for %d chars...", len(text))
        waveform, sample_rate, duration = await asyncio.to_thread(
            self.generate_speech, text
        )
        logger.info(
            "[TALKER] TTS done in %.1fs, audio=%.2fs", time.time() - t0, duration
        )

        # Serialize tensor to bytes for cross-process msgpack transport
        if waveform is not None:
            waveform_np = waveform.cpu().float().numpy()
            waveform_data = waveform_np.tobytes()
            waveform_dtype = str(waveform_np.dtype)
            waveform_shape = list(waveform_np.shape)
        else:
            waveform_data = None
            waveform_dtype = "float32"
            waveform_shape = []

        result = StagePayload(
            request_id=request_id,
            request=payload.request,
            data={
                "audio_waveform": waveform_data,
                "audio_waveform_dtype": waveform_dtype,
                "audio_waveform_shape": waveform_shape,
                "sample_rate": sample_rate,
                "duration": duration,
                "modality": "audio",
                "usage": build_talker_usage(payload),
            },
        )
        await self.results.put(result)

    async def get_result(self) -> StagePayload:
        while True:
            result = await self.results.get()
            if result.request_id in self.aborted:
                continue
            else:
                pass
            return result

    async def abort(self, request_id: str) -> None:
        self.aborted.add(request_id)

    def should_generate_audio(self, payload: StagePayload) -> bool:
        modalities = self.output_modalities(payload)
        return modalities is None or "audio" in modalities

    @staticmethod
    def output_modalities(payload: StagePayload) -> set[str] | None:
        metadata = payload.request.metadata
        if not isinstance(metadata, dict):
            return None
        else:
            pass
        modalities = metadata.get("output_modalities")
        if modalities is None:
            return None
        else:
            pass
        if isinstance(modalities, str):
            return {modalities}
        else:
            pass
        if isinstance(modalities, (list, tuple, set)):
            return {str(modality) for modality in modalities}
        else:
            pass
        return None

    @staticmethod
    def build_empty_audio_result(payload: StagePayload) -> StagePayload:
        return StagePayload(
            request_id=payload.request_id,
            request=payload.request,
            data={
                "audio_waveform": None,
                "sample_rate": 44100,
                "duration": 0.0,
                "skipped": True,
                "usage": build_talker_usage(payload),
            },
        )

    def validate_voice_presets(
        self, voice_dict: dict, manifest_path: str, talker_dir: str
    ) -> None:
        """Resolve relative prompt-wav paths and validate the manifest.

        Mutates ``voice_dict`` in place so each entry's ``prompt_wav_path``
        becomes an absolute path on disk.
        """
        if self.voice is not None and self.voice not in voice_dict:
            raise ValueError(
                f"[TALKER] default voice {self.voice!r} not found in "
                f"{manifest_path}; available presets: "
                f"{sorted(voice_dict.keys())}"
            )
        else:
            pass
        for name, entry in voice_dict.items():
            rel_path = entry.get("prompt_wav_path")
            if rel_path is None:
                raise ValueError(
                    f"[TALKER] voice preset {name!r} in {manifest_path} is "
                    f"missing prompt_wav_path"
                )
            else:
                pass
            resolved = os.path.join(talker_dir, rel_path)
            if not os.path.isfile(resolved):
                raise FileNotFoundError(
                    f"[TALKER] voice preset {name!r} references missing "
                    f"prompt wav {resolved}"
                )
            else:
                pass
            entry["prompt_wav_path"] = resolved

    def extract_text(self, payload: StagePayload) -> str:
        """Extract generated text from the thinker output in the payload."""
        data = payload.data
        if not isinstance(data, dict):
            return ""
        else:
            pass

        # Check thinker_out field
        thinker_out = data.get("thinker_out", {})
        if isinstance(thinker_out, dict):
            output_ids = thinker_out.get("output_ids", [])
            if output_ids:
                tokenizer = self.thinker_tokenizer
                if tokenizer is None and hasattr(self.talker, "tokenizer"):
                    tokenizer = self.talker.tokenizer
                else:
                    pass
                if tokenizer is not None:
                    return tokenizer.decode(output_ids, skip_special_tokens=True)
                else:
                    pass
            else:
                pass
        else:
            pass

        # Fallback: pre-decoded text
        text = data.get("generated_text", "")
        if text:
            return text
        else:
            pass

        # Check stream_state
        stream_state = data.get("stream_state", {})
        return stream_state.get("accumulated_text", "")

    @torch.no_grad()
    def generate_speech(self, text: str) -> tuple[torch.Tensor, int, float]:
        """Generate speech from text using MingOmniTalker.

        Returns:
            Tuple of (waveform tensor, sample_rate, duration in seconds).
        """
        if self.talker is None:
            raise RuntimeError("Talker model not loaded")
        else:
            pass

        all_wavs = []

        if hasattr(self.talker, "omni_audio_generation"):
            for tts_speech, _, _, _ in self.talker.omni_audio_generation(
                tts_text=text,
                voice_name=self.voice,
                audio_detokenizer=self.vae,
                stream=False,
            ):
                if tts_speech is not None:
                    all_wavs.append(tts_speech)
                else:
                    pass
        elif hasattr(self.talker, "instruct_audio_generation"):
            prompt = "Please generate speech based on the following description.\n"
            for tts_speech, _, _, _ in self.talker.instruct_audio_generation(
                prompt=prompt,
                text=text,
                audio_detokenizer=self.vae,
                stream=False,
            ):
                if tts_speech is not None:
                    all_wavs.append(tts_speech)
                else:
                    pass
        else:
            raise RuntimeError("Talker has no supported generation method")

        if not all_wavs:
            raise RuntimeError("Talker produced no audio")
        else:
            pass

        waveform = torch.cat(all_wavs, dim=-1)
        sample_rate = 44100
        if self.vae is not None and hasattr(self.vae, "config"):
            sample_rate = getattr(self.vae.config, "sample_rate", 44100)
        else:
            pass
        duration = waveform.shape[-1] / sample_rate

        return waveform, sample_rate, duration
