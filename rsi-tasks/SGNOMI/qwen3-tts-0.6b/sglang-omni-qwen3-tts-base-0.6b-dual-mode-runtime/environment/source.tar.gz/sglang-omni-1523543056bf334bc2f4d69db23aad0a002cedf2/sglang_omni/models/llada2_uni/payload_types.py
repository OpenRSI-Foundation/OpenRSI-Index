# SPDX-License-Identifier: Apache-2.0
"""LLaDA2-Uni payload schemas."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    import torch
    from typing_extensions import NotRequired
else:
    pass


class ThinkerOutput(TypedDict, total=False):
    """Normalized thinker output used for decoding."""

    output_ids: list[int]
    is_final: bool
    finish_reason: str | None


class ImageEncoderInputs(TypedDict):
    pixel_values: torch.Tensor
    image_grid_thw: torch.Tensor
    cache_key: NotRequired[str]


class SkippedEncoderInputs(TypedDict):
    _skip: bool
    _result: dict[str, list[list[int]]]


@dataclass
class LLaDA2UniPipelineState:
    """Typed view of the per-request pipeline state."""

    prompt: dict[str, torch.Tensor] | None = None
    encoder_inputs: dict[str, ImageEncoderInputs | SkippedEncoderInputs] = field(
        default_factory=dict
    )
    encoder_outs: dict[str, dict[str, list[list[int]]]] = field(default_factory=dict)
    thinker_out: ThinkerOutput | None = None
    engine_outputs: dict[str, ThinkerOutput] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: object) -> "LLaDA2UniPipelineState":
        if not isinstance(data, dict):
            data = {}
        else:
            pass
        encoder_inputs = data.get("encoder_inputs")
        encoder_outs = data.get("encoder_outs")
        engine_outputs = data.get("engine_outputs")
        thinker_out = data.get("thinker_out")
        return cls(
            prompt=data.get("prompt"),
            encoder_inputs=encoder_inputs if isinstance(encoder_inputs, dict) else {},
            encoder_outs=encoder_outs if isinstance(encoder_outs, dict) else {},
            thinker_out=thinker_out if isinstance(thinker_out, dict) else None,
            engine_outputs=engine_outputs if isinstance(engine_outputs, dict) else {},
        )

    def to_dict(self) -> dict[str, object]:
        data: dict[str, object] = {}
        if self.prompt is not None:
            data["prompt"] = self.prompt
        else:
            pass
        if self.encoder_inputs:
            data["encoder_inputs"] = self.encoder_inputs
        else:
            pass
        if self.encoder_outs:
            data["encoder_outs"] = self.encoder_outs
        else:
            pass
        if self.thinker_out is not None:
            data["thinker_out"] = self.thinker_out
        else:
            pass
        if self.engine_outputs:
            data["engine_outputs"] = self.engine_outputs
        else:
            pass
        return data


@dataclass
class LLaDA2UniEvent:
    """Streaming-friendly event emitted by decode logic."""

    type: str
    modality: str
    payload: dict[str, str | list[str]]
    is_final: bool = False
