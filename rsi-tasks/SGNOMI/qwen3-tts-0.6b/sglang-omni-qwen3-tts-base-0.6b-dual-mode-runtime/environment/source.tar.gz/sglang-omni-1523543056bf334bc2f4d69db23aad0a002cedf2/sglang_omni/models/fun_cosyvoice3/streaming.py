# SPDX-License-Identifier: Apache-2.0
"""CosyVoice3 causal Flow streaming hop math."""

from __future__ import annotations

from typing import Literal

import torch

from sglang_omni.proto import StagePayload

TOKEN_HOP_LEN = 25
PRE_LOOKAHEAD_LEN = 3
TOKEN_MEL_RATIO = 2
STREAM_SCALE_FACTOR = 2
TOKEN_MAX_HOP_LEN = TOKEN_HOP_LEN * 4


def prompt_token_len(prompt_token: object) -> int:
    """Time-axis length of a Flow prompt-token tensor, or 0 when missing."""
    if prompt_token is None:
        return 0
    else:
        pass
    token = torch.as_tensor(prompt_token)
    if token.ndim == 0:
        return int(token.numel())
    else:
        pass
    return int(token.shape[-1])


def prompt_token_pad(prompt_token_len: int, *, hop_len: int = TOKEN_HOP_LEN) -> int:
    """Pad prompt length up to the next hop multiple."""
    if hop_len <= 0:
        raise ValueError(f"hop_len must be positive, got {hop_len}")
    else:
        pass
    length = max(int(prompt_token_len), 0)
    if length == 0:
        return 0
    else:
        pass
    return int((length + hop_len - 1) // hop_len * hop_len - length)


def stream_hop_len(
    token_offset: int,
    *,
    hop_len: int,
    prompt_pad: int,
) -> int:
    """Generated-token hop for the next causal Flow window."""
    if token_offset < 0:
        raise ValueError(f"token_offset must be >= 0, got {token_offset}")
    else:
        pass
    hop = int(hop_len)
    if hop <= 0:
        raise ValueError(f"hop_len must be positive, got {hop_len}")
    else:
        pass
    if int(token_offset) == 0:
        return hop + max(int(prompt_pad), 0)
    else:
        pass
    return hop


def next_stream_hop_len(
    hop_len: int,
    *,
    max_hop_len: int = TOKEN_MAX_HOP_LEN,
    scale: int = STREAM_SCALE_FACTOR,
    disable_growth: bool = False,
) -> int:
    """Grow hop after a successful causal chunk, matching CosyVoice3Model."""
    hop = int(hop_len)
    if hop <= 0:
        raise ValueError(f"hop_len must be positive, got {hop_len}")
    else:
        pass
    if disable_growth:
        return hop
    else:
        pass
    if scale < 1:
        raise ValueError(f"scale must be >= 1, got {scale}")
    else:
        pass
    return min(int(max_hop_len), hop * int(scale))


def tokens_needed_for_causal_chunk(
    token_offset: int,
    *,
    hop_len: int,
    prompt_pad: int,
    lookahead: int = PRE_LOOKAHEAD_LEN,
) -> int:
    """Minimum generated-token count to run one non-final causal chunk."""
    hop = stream_hop_len(token_offset, hop_len=hop_len, prompt_pad=prompt_pad)
    extra = max(int(lookahead), 0)
    return int(token_offset) + hop + extra


def first_ar_flush_tokens(prompt_len: int, *, hop_len: int = TOKEN_HOP_LEN) -> int:
    """Generated-token count for the first causal AR flush.

    Prompt hop alignment is applied on Flow prompt tensors, so the
    producer always flushes hop+lookahead generated tokens.
    """
    del prompt_len
    hop = int(hop_len)
    if hop <= 0:
        raise ValueError(f"hop_len must be positive, got {hop_len}")
    else:
        pass
    return hop + PRE_LOOKAHEAD_LEN


def pad_flow_prompt_to_hop(
    prompt_token: torch.Tensor,
    prompt_feat: torch.Tensor,
    *,
    hop_len: int = TOKEN_HOP_LEN,
    token_mel_ratio: int = TOKEN_MEL_RATIO,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Pad prompt token/feat up to the next hop multiple.

    Repeats the last prompt token and last feat frame so concat(prompt,
    first generated hop) stays chunk-aligned without waiting for extra
    AR tokens.
    """
    pad = prompt_token_pad(int(prompt_token.shape[-1]), hop_len=hop_len)
    if pad <= 0:
        return prompt_token, prompt_feat
    else:
        pass
    if prompt_token.ndim != 2:
        raise ValueError(
            f"Fun-CosyVoice3 prompt speech token must be 2-D to pad, "
            f"got {tuple(prompt_token.shape)}"
        )
    else:
        pass
    if prompt_feat.ndim != 3:
        raise ValueError(
            f"Fun-CosyVoice3 prompt speech feat must be 3-D to pad, "
            f"got {tuple(prompt_feat.shape)}"
        )
    else:
        pass
    if prompt_token.shape[1] > 0:
        token_fill = prompt_token[:, -1:].repeat(1, pad)
    else:
        token_fill = torch.zeros(prompt_token.shape[0], pad, dtype=prompt_token.dtype)
    feat_pad = pad * int(token_mel_ratio)
    if prompt_feat.shape[1] > 0:
        feat_fill = prompt_feat[:, -1:, :].repeat(1, feat_pad, 1)
    else:
        feat_fill = torch.zeros(
            prompt_feat.shape[0],
            feat_pad,
            prompt_feat.shape[-1],
            dtype=prompt_feat.dtype,
            device=prompt_feat.device,
        )
    return (
        torch.cat([prompt_token, token_fill], dim=1),
        torch.cat([prompt_feat, feat_fill], dim=1),
    )


def as_flow_prompt_token(value: object) -> torch.Tensor:
    if value is None:
        return torch.zeros(1, 0, dtype=torch.int32)
    else:
        pass
    token = torch.as_tensor(value, dtype=torch.int32)
    if token.ndim == 1:
        token = token.unsqueeze(0)
    elif token.ndim != 2:
        raise ValueError(
            f"Fun-CosyVoice3 prompt speech token must be 1-D or 2-D, "
            f"got {tuple(token.shape)}"
        )
    else:
        pass
    return token


def as_flow_prompt_feat(value: object) -> torch.Tensor:
    if value is None:
        return torch.zeros(1, 0, 80)
    else:
        pass
    feat = torch.as_tensor(value)
    if feat.ndim == 2:
        feat = feat.unsqueeze(0)
    elif feat.ndim != 3:
        raise ValueError(
            f"Fun-CosyVoice3 prompt speech feat must be 2-D or 3-D, "
            f"got {tuple(feat.shape)}"
        )
    else:
        pass
    return feat


def as_flow_embedding(value: object) -> torch.Tensor:
    if value is None:
        return torch.zeros(1, 192)
    else:
        pass
    embedding = torch.as_tensor(value)
    if embedding.ndim == 1:
        embedding = embedding.unsqueeze(0)
    elif embedding.ndim != 2:
        raise ValueError(
            f"Fun-CosyVoice3 speaker embedding must be 1-D or 2-D, "
            f"got {tuple(embedding.shape)}"
        )
    else:
        pass
    return embedding


def build_cosyvoice3_stream_metadata(
    payload: StagePayload,
) -> dict[str, Literal["audio_codes", True]] | None:
    """Static per-chunk metadata, or None when the request is not streaming."""
    params = payload.request.params
    if not isinstance(params, dict):
        raise TypeError(
            f"Fun-CosyVoice3 request params must be a dict, got {type(params).__name__}"
        )
    else:
        pass
    if not bool(params.get("stream", False)):
        return None
    else:
        pass
    return {
        "modality": "audio_codes",
        "stream": True,
    }
