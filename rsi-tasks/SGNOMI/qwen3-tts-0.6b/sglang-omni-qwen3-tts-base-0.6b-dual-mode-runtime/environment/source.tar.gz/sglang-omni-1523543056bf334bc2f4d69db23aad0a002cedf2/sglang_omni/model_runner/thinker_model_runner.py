# SPDX-License-Identifier: Apache-2.0
"""Thinker model runner — injects multimodal embeddings before forward.

Handles image/video/audio token → embedding replacement and deepstack
visual embeddings for Qwen3-Omni's thinker stage.
"""

from __future__ import annotations

import logging
from numbers import Integral
from typing import TYPE_CHECKING

import torch
from sglang.srt.layers.logits_processor import LogitsProcessorOutput
from sglang.srt.managers.schedule_batch import Req, ScheduleBatch
from sglang.srt.managers.scheduler import GenerationBatchResult
from sglang.srt.model_executor.forward_batch_info import CaptureHiddenMode, ForwardBatch

from sglang_omni.model_runner.base import ModelRunner
from sglang_omni.model_runner.model_worker import ModelWorker
from sglang_omni.model_runner.sglang_execution import attn_forward_context
from sglang_omni.scheduling.sglang_backend.output_processor import SGLangOutputProcessor
from sglang_omni.scheduling.types import SchedulerRequest

if TYPE_CHECKING:
    from sglang.srt.hardware_backend.mlx.tp_worker import MlxTpModelWorker

else:
    pass

logger = logging.getLogger(__name__)


class ThinkerModelRunner(ModelRunner):
    def __init__(
        self,
        tp_worker: ModelWorker | MlxTpModelWorker,
        output_processor: SGLangOutputProcessor,
    ) -> None:
        super().__init__(tp_worker, output_processor)

        model = self.model
        self.outer_model = model.thinker
        self.text_model = self.outer_model.model
        self.embed_tokens = self.text_model.embed_tokens
        self.th_host_bufs: list[torch.Tensor] | None = None
        self.th_slot = 0

        thinker_cfg = tp_worker.model_runner.model_config.hf_config.thinker_config
        self.image_token_id = thinker_cfg.image_token_id
        self.video_token_id = thinker_cfg.video_token_id
        self.audio_token_id = thinker_cfg.audio_token_id

    def custom_prefill_forward(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> GenerationBatchResult | None:
        if not schedule_batch.forward_mode.is_extend():
            return None
        else:
            pass

        omni_result = self.inject_multimodal_embeds(forward_batch, schedule_batch)
        if omni_result is not None and omni_result[0] is not None:
            input_embeds, ds_embeds, vis_masks = omni_result
            # note (jun): SGLang owns ordinary input embeds and attention
            # dispatch; deepstack uses the custom forward because ForwardBatch
            # cannot carry its residual embeddings.
            if ds_embeds is None:
                forward_batch.input_embeds = input_embeds
                return None
            else:
                pass
            return self.forward_with_omni_embeds(
                forward_batch, input_embeds, ds_embeds, vis_masks
            )
        else:
            pass
        return None

    # note (ratish): the thinker reads no SGLang hidden states, and a request asking
    # for them would raise the batch capture mode above the graph's and run eager
    def requested_capture_hidden_mode_prefill(
        self, schedule_batch: ScheduleBatch, requests: list[SchedulerRequest]
    ) -> CaptureHiddenMode:
        del schedule_batch, requests
        from sglang.srt.model_executor.forward_batch_info import CaptureHiddenMode

        return CaptureHiddenMode.NULL

    def requested_capture_hidden_mode_decode(
        self, schedule_batch: ScheduleBatch, requests: list[SchedulerRequest]
    ) -> CaptureHiddenMode:
        del schedule_batch, requests
        from sglang.srt.model_executor.forward_batch_info import CaptureHiddenMode

        return CaptureHiddenMode.NULL

    # ------------------------------------------------------------------
    # Multimodal embedding injection
    # ------------------------------------------------------------------

    def req_mm_token_positions(
        self,
        req: Req,
        pad_values: dict,
    ) -> dict[str, torch.Tensor]:
        """Prompt-absolute placeholder positions per modality, as CPU int64
        tensors so the merge never reads placement off a GPU mask."""
        positions = getattr(
            req, "_omni_mm_positions", None
        )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        if positions is not None:
            return positions
        else:
            pass
        prompt_ids = torch.as_tensor(req.origin_input_ids, dtype=torch.long)
        positions = {
            modality: (prompt_ids == pad_values.get(modality, default_id)).nonzero(
                as_tuple=True
            )[0]
            for modality, default_id in (
                ("image", self.image_token_id),
                ("video", self.video_token_id),
                ("audio", self.audio_token_id),
            )
        }
        req._omni_mm_positions = positions  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        return positions

    @staticmethod
    def plan_modality_chunk(
        positions: torch.Tensor,
        consumed: dict[str, int],
        modality: str,
        prefix: int,
        length: int,
    ) -> tuple[torch.Tensor, int, int]:
        """Plan the embed slice for positions in ``[prefix, prefix + length)``.

        The caller owns cursor advancement; this helper never mutates ``consumed``.
        """
        in_chunk = (positions >= prefix) & (positions < prefix + length)
        relative_positions = positions[in_chunk] - prefix
        return (
            relative_positions,
            consumed.get(modality, 0),
            relative_positions.numel(),
        )

    @staticmethod
    def ensure_consumed_cursor(
        req: Req,
    ) -> dict[str, int]:
        consumed = (
            req._omni_consumed
        )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        if consumed is None:
            consumed = {}
            req._omni_consumed = consumed  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        elif not isinstance(consumed, dict):
            raise TypeError(
                "req._omni_consumed must be None or a dict, "
                f"got {type(consumed).__name__}"
            )
        else:
            pass
        return consumed

    @staticmethod
    def validate_modality_cursor(
        modality: str, offset: object, row_count: int, live_count: int
    ) -> int:
        if not isinstance(offset, Integral) or isinstance(offset, bool):
            raise TypeError(
                f"Invalid {modality} multimodal cursor: expected a non-negative "
                f"integer, got {offset!r}"
            )
        else:
            pass
        offset = int(offset)
        if offset < 0:
            raise ValueError(
                f"Invalid {modality} multimodal cursor: offset {offset} is negative"
            )
        else:
            pass
        if offset > row_count or offset + live_count > row_count:
            raise ValueError(
                f"Invalid {modality} multimodal cursor: source range "
                f"[{offset}, {offset + live_count}) exceeds {row_count} embedding rows"
            )
        else:
            pass
        return offset

    @staticmethod
    def reconstruct_missing_cursor(
        modality: str,
        positions: torch.Tensor,
        prefix: int,
        row_count: int,
    ) -> int | None:
        """Recover a missing cursor only when cached rows map unambiguously."""
        position_count = positions.numel()
        if prefix <= 0 or position_count == 0:
            return None
        else:
            pass

        cached_count = positions[positions < prefix].numel()
        if cached_count == 0 or cached_count == position_count:
            return None
        else:
            pass
        if position_count != row_count:
            raise ValueError(
                f"Cannot reconstruct {modality} multimodal cursor: "
                f"{position_count} prompt placeholders do not map one-to-one "
                f"to {row_count} embedding rows"
            )
        else:
            pass
        return cached_count

    def inject_multimodal_embeds(
        self, forward_batch: ForwardBatch | None, schedule_batch: ScheduleBatch
    ) -> tuple[torch.Tensor, list[torch.Tensor] | None, torch.Tensor | None] | None:
        if not any(req.omni_model_inputs is not None for req in schedule_batch.reqs):
            return None
        else:
            pass

        device = forward_batch.input_ids.device

        embed_input_ids = forward_batch.input_ids.clamp(
            0, self.embed_tokens.num_embeddings - 1
        )
        input_embeds = self.embed_tokens(embed_input_ids)

        # note (chenrui): these arrive as CPU tensors on some sglang paths, where
        # int(tensor[i]) per request would put a .item() on the hot path.
        extend_lens = forward_batch.extend_seq_lens_cpu
        prefix_lens = forward_batch.extend_prefix_lens_cpu
        if isinstance(extend_lens, torch.Tensor):
            extend_lens = extend_lens.tolist()
        else:
            pass
        if isinstance(prefix_lens, torch.Tensor):
            prefix_lens = prefix_lens.tolist()
        else:
            pass
        offsets = []
        pos = 0
        for length in extend_lens:
            offsets.append(pos)
            pos += length

        scatter_rows: list[torch.Tensor] = []
        scatter_srcs: list[torch.Tensor] = []
        deepstack_visual_embeds_list = []
        visual_rows: list[torch.Tensor] = []

        for i, req in enumerate(schedule_batch.reqs):
            omni_inputs = req.omni_model_inputs
            if omni_inputs is None:
                continue
            else:
                pass

            start = offsets[i]
            length = extend_lens[i]
            prefix = 0 if prefix_lens is None else int(prefix_lens[i])
            consumed = self.ensure_consumed_cursor(req)
            chunk_offsets: dict[str, tuple[int, int]] = {}
            pad_values = omni_inputs.get("pad_values", {})

            positions = self.req_mm_token_positions(req, pad_values)
            chunk_positions: dict[str, torch.Tensor] = {}
            for modality in ("image", "video", "audio"):
                rel, offset, n_tokens = self.plan_modality_chunk(
                    positions[modality], consumed, modality, prefix, length
                )
                chunk_positions[modality] = rel
                embeds = omni_inputs.get(f"{modality}_embeds")
                if embeds is None:
                    continue
                else:
                    pass
                row_count = embeds.shape[0]
                if modality not in consumed:
                    reconstructed_offset = self.reconstruct_missing_cursor(
                        modality,
                        positions[modality],
                        prefix,
                        row_count,
                    )
                    if reconstructed_offset is not None:
                        consumed[modality] = reconstructed_offset
                        offset = reconstructed_offset
                    else:
                        pass
                else:
                    pass
                offset = self.validate_modality_cursor(
                    modality, offset, row_count, n_tokens
                )
                if n_tokens:
                    chunk_offsets[modality] = (offset, n_tokens)
                    chunk_embeds = embeds[offset : offset + n_tokens]
                    scatter_rows.append(rel + start)
                    scatter_srcs.append(chunk_embeds)
                    consumed[modality] = offset + n_tokens
                else:
                    pass

            ds_embeds = omni_inputs.get("deepstack_visual_embeds")
            image_ds = omni_inputs.get("image_deepstack_visual_embeds")
            video_ds = omni_inputs.get("video_deepstack_visual_embeds")

            if ds_embeds is not None or image_ds is not None or video_ds is not None:
                img_pos = chunk_positions["image"]
                vid_pos = chunk_positions["video"]
                # note (chenrui): unique modality positions make this sort
                # tie-free; its inverse below preserves prompt order without
                # device-mask synchronization.
                visual_pos, visual_order = torch.sort(torch.cat([img_pos, vid_pos]))
                visual_count = visual_pos.numel()

                if ds_embeds is None:
                    if image_ds and video_ds:
                        image_offset, image_count = chunk_offsets.get("image", (0, 0))
                        video_offset, video_count = chunk_offsets.get("video", (0, 0))
                        slots = torch.empty_like(visual_order)
                        slots[visual_order] = torch.arange(
                            visual_count, device=slots.device
                        )
                        n_image = img_pos.numel()
                        img_idx = slots[:n_image].to(device)
                        vid_idx = slots[n_image:].to(device)
                        merged = []
                        for img_e, vid_e in zip(image_ds, video_ds):
                            img_e = img_e[image_offset : image_offset + image_count]
                            vid_e = vid_e[video_offset : video_offset + video_count]
                            joint = img_e.new_zeros(
                                visual_count, img_e.shape[-1], device=device
                            )
                            joint[img_idx] = img_e.to(device=device)
                            joint[vid_idx] = vid_e.to(device=device)
                            merged.append(joint)
                        ds_embeds = merged
                    elif image_ds:
                        image_offset, image_count = chunk_offsets.get("image", (0, 0))
                        ds_embeds = [
                            layer[image_offset : image_offset + image_count]
                            for layer in image_ds
                        ]
                    elif video_ds:
                        video_offset, video_count = chunk_offsets.get("video", (0, 0))
                        ds_embeds = [
                            layer[video_offset : video_offset + video_count]
                            for layer in video_ds
                        ]
                    else:
                        pass
                elif visual_count > 0:
                    if not img_pos.numel():
                        visual_offset = chunk_offsets.get("video", (0, 0))[0]
                    elif not vid_pos.numel():
                        visual_offset = chunk_offsets.get("image", (0, 0))[0]
                    else:
                        visual_offset = consumed.get("_visual", 0)
                    ds_embeds = [
                        layer[visual_offset : visual_offset + visual_count]
                        for layer in ds_embeds
                    ]
                    consumed["_visual"] = visual_offset + visual_count
                else:
                    ds_embeds = None

                if ds_embeds is not None:
                    deepstack_visual_embeds_list.append(ds_embeds)
                    visual_rows.append(visual_pos + start)
                else:
                    pass
            else:
                pass

            if req.inflight_middle_chunks == 0:
                req.omni_model_inputs = None
                req._omni_consumed = None  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
                req._omni_mm_positions = None  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
            else:
                pass

        if scatter_rows:
            # note (chenrui): one index_copy_ keeps the kernel count independent
            # of batch mix; avoid concatenating the common single-source case.
            row_idx = torch.cat(scatter_rows).to(device=device)
            srcs = [
                s.to(device=device, dtype=input_embeds.dtype, non_blocking=True)
                for s in scatter_srcs
            ]
            src = srcs[0] if len(srcs) == 1 else torch.cat(srcs, dim=0)
            input_embeds.index_copy_(0, row_idx, src)
        else:
            pass

        ds_embeds_out = None
        visual_masks_out = None
        if deepstack_visual_embeds_list:
            combined_mask = torch.zeros(
                len(forward_batch.input_ids), dtype=torch.bool, device=device
            )
            combined_mask[torch.cat(visual_rows).to(device=device)] = True
            visual_masks_out = combined_mask
            if len(deepstack_visual_embeds_list) == 1:
                ds_embeds_out = deepstack_visual_embeds_list[0]
            else:
                num_layers = len(deepstack_visual_embeds_list[0])
                merged_ds = []
                for layer_idx in range(num_layers):
                    parts = [
                        req_ds[layer_idx].to(device=device, dtype=input_embeds.dtype)
                        for req_ds in deepstack_visual_embeds_list
                    ]
                    merged_ds.append(torch.cat(parts, dim=0))
                ds_embeds_out = merged_ds
        else:
            pass

        return input_embeds, ds_embeds_out, visual_masks_out

    # ------------------------------------------------------------------
    # Custom forward with multimodal embeddings + deepstack
    # ------------------------------------------------------------------

    def forward_with_omni_embeds(
        self,
        forward_batch: ForwardBatch,
        input_embeds: torch.Tensor,
        deepstack_visual_embeds: list[torch.Tensor] | None = None,
        visual_pos_masks: torch.Tensor | None = None,
    ) -> GenerationBatchResult:
        model_runner = self.tp_worker.model_runner
        outer = self.outer_model

        model_runner.attn_backend.init_forward_metadata(forward_batch)

        positions = forward_batch.positions
        if forward_batch.mrope_positions is not None:
            positions = forward_batch.mrope_positions
        else:
            pass

        ds_input = None
        if deepstack_visual_embeds is not None and visual_pos_masks is not None:
            device = input_embeds.device
            dtype = input_embeds.dtype
            layer_tensors = [
                t.to(device=device, dtype=dtype) for t in deepstack_visual_embeds
            ]
            ds_input = torch.cat(layer_tensors, dim=-1)
            full_ds = torch.zeros(
                input_embeds.shape[0], ds_input.shape[-1], device=device, dtype=dtype
            )
            full_ds[visual_pos_masks] = ds_input
            ds_input = full_ds
        else:
            pass

        with attn_forward_context(model_runner.attn_backend):
            hidden_states = outer.model(
                input_ids=None,
                positions=positions,
                forward_batch=forward_batch,
                input_embeds=input_embeds,
                input_deepstack_embeds=ds_input,
            )

            logits_output = outer.logits_processor(
                forward_batch.input_ids,
                hidden_states,
                outer.lm_head,
                forward_batch,
            )

        return GenerationBatchResult(
            logits_output=logits_output, can_run_cuda_graph=False
        )

    def lookahead_eligible(self, batch: ScheduleBatch) -> bool:
        """Reject batches that must decode synchronously.

        MiniCPM-o speech reads hidden states at resolve, after the next launch
        overwrote them; a Qwen speech lookahead takes GPU time from the colocated
        talker. History-dependent or unsupported sampling needs sync for parity.
        """
        from sglang_omni.models.qwen3_omni.request_builders import (
            should_generate_audio_output,
        )

        for req in batch.reqs:
            # note (jiaxin deng): fail closed if the request data is missing or None
            # so a hidden-capture batch can never slip onto the async path.
            try:
                data = (
                    req.omni_data
                )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
            except AttributeError:
                data = None
            if data is None or should_generate_audio_output(data.stage_payload):
                return False
            else:
                pass
            try:
                needs_logprob = data.return_logprob
            except AttributeError:
                needs_logprob = False
            if needs_logprob:
                return False
            else:
                pass
            sp = req.sampling_params
            if (
                sp.repetition_penalty != 1.0
                or sp.presence_penalty != 0.0
                or sp.frequency_penalty != 0.0
                or sp.min_new_tokens > 0
                or sp.sampling_seed is not None
                or sp.logit_bias is not None
                or sp.custom_params
            ):
                return False
            else:
                pass
        return True

    def async_host_buf(self, like: torch.Tensor, n: int) -> torch.Tensor:
        # note (jiaxin deng): two pinned buffers ping-ponged so resolve(N) reads
        # one while launch(N+1) writes the other.
        if self.th_host_bufs is None or self.th_host_bufs[0].shape[0] < n:
            self.th_host_bufs = [
                torch.empty(n, dtype=like.dtype, device="cpu", pin_memory=True)
                for _ in range(2)
            ]
            self.th_slot = 0
        else:
            pass
        buf = self.th_host_bufs[self.th_slot]
        self.th_slot ^= 1
        return buf

    def sample_lookahead(
        self,
        logits_output: LogitsProcessorOutput,
        forward_batch: ForwardBatch,
        requests: list[SchedulerRequest],
    ) -> torch.Tensor:
        # note (jiaxin deng): penalties never reach here (lookahead_eligible routes
        # those batches to sync); only static suppress tokens are lag-safe.
        self.apply_codec_suppress_tokens(logits_output, requests)
        return self.tp_worker.model_runner.sample(logits_output, forward_batch)

    def post_decode_launch(
        self,
        result: GenerationBatchResult | None,
        forward_batch: ForwardBatch | None,
        requests: list[SchedulerRequest],
    ) -> torch.Tensor | None:
        n = len(requests)
        if n == 0:
            return None
        else:
            pass
        # note (jiaxin deng): the decode forward leaves next_token_ids None (sync
        # samples in _finalize); set it here for the next-step input chain.
        if result.next_token_ids is None:
            result.next_token_ids = self.sample_lookahead(
                result.logits_output, forward_batch, requests
            )
        else:
            pass
        nt = result.next_token_ids
        host_buf = self.async_host_buf(nt, n)
        host_buf[:n].copy_(nt[:n], non_blocking=True)
        return host_buf

    def post_decode_resolve(
        self,
        launch_buf: torch.Tensor | None,
        result: GenerationBatchResult | None,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> None:
        del forward_batch, schedule_batch
        if len(requests) == 0 or launch_buf is None:
            return
        else:
            pass
        n = len(requests)
        result.next_token_ids = launch_buf[:n].to(torch.long).clone()
