# SPDX-License-Identifier: Apache-2.0
"""Base model runner — shared execute() pipeline for all AR models.

Handles: ForwardBatch construction, phase-aware pre/post hooks, forward
pass, sampling, logit post-processing, and output extraction.
"""

from __future__ import annotations

from collections import Counter
from contextlib import AbstractContextManager
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Generic, Protocol, TypeAlias

import torch

from sglang_omni.model_runner.model_worker import ModelWorker
from sglang_omni.model_runner.prefill_inputs import clear_omni_prefill_inputs
from sglang_omni.model_runner.sglang_execution import SGLangExecutionBridge
from sglang_omni.platforms import current_platform
from sglang_omni.sampling.seed import (
    SAMPLING_SEED_MASK,
    derive_sampling_seed,
    resolve_row_seed,
)
from sglang_omni.scheduling.types import (
    ModelRunnerOutput,
    RequestDataInput,
    RequestOutput,
    SchedulerOutput,
    SchedulerRequest,
    sampled_logprobs_to_list,
)

if TYPE_CHECKING:
    from sglang.srt.hardware_backend.mlx.tp_worker import MlxTpModelWorker
    from sglang.srt.layers.logits_processor import LogitsProcessorOutput
    from sglang.srt.managers.schedule_batch import Req, ScheduleBatch
    from sglang.srt.managers.scheduler import GenerationBatchResult
    from sglang.srt.model_executor.forward_batch_info import (
        CaptureHiddenMode,
        ForwardBatch,
    )
    from sglang.srt.sampling.sampling_batch_info import SamplingBatchInfo

    from sglang_omni.models.dots_tts.model_runner import DotsFlowLaunchBuf
    from sglang_omni.scheduling.sglang_backend.output_processor import (
        SGLangOutputProcessor,
    )

    DecodeLaunchBuffer: TypeAlias = (
        torch.Tensor
        | tuple[torch.Tensor, torch.Tensor | None]
        | tuple[
            list[SchedulerRequest],
            torch.Tensor,
            int,
            torch.Tensor,
            torch.cuda.Event | torch.xpu.Event,
        ]
        | DotsFlowLaunchBuf
        | None
    )
else:
    pass


class CompletionEvent(Protocol):
    def query(self) -> bool: ...

    def synchronize(self) -> None: ...


def current_sglang_sampling_backend() -> str | None:
    try:
        from sglang.srt.runtime_context import get_exec

        return get_exec().kernel.sampling_backend
    except ValueError:
        return None


def rank_shared_unseeded_sampling_seed(request: SchedulerRequest, row_idx: int) -> int:
    request_id = request.request_id or f"row-{row_idx}"
    return derive_sampling_seed("sglang-omni-unseeded-row", request_id)


def resolve_deferred_prefill_inputs(
    schedule_batch: ScheduleBatch, device: torch.device
) -> None:
    """Materialize staged CPU prefill inputs before a direct worker forward.

    Scheduler-owned execution resolves staging through SGLangExecutionBridge;
    DllmScheduler calls this before invoking the worker directly.
    """
    staged_input_ids = schedule_batch.prefill_input_ids_cpu
    if staged_input_ids is None:
        return
    else:
        pass

    if schedule_batch.mix_running_indices is not None:
        raise RuntimeError(
            "Omni does not support SGLang mixed chunked-prefill batches with "
            "deferred decode tokens"
        )
    else:
        pass

    schedule_batch.input_ids = staged_input_ids.to(device, non_blocking=True)
    schedule_batch.prefill_input_ids_cpu = None


@dataclass
class PendingStep:
    """One decode step launched on the GPU but not yet consumed on the host.

    Async-decode (one-step lookahead) bookkeeping: a launched step has its
    forward + on-GPU sample + collect enqueued and ``event`` recorded right
    after, so ``event.query()`` true means the launched step's GPU work is
    published. ``launch_buf`` is whatever ``post_decode_launch`` returns for
    resolve to consume: a device-side correctness snapshot of the published ids
    (MOSS-TTS-Local, no host copy), or a pinned host staging buffer an async host
    copy filled (Higgs); only the latter provides host-D2H overlap.
    ``execute_resolve`` later waits on ``event`` and reads ``launch_buf``.

    Invariant: at most one ``_PendingStep`` is live at a time (see
    ``ModelRunner._pending``). When the launch uses host staging it is pinned
    and ping-ponged between two buffers so resolve(N) reads one while
    launch(N+1) writes the other (design.md section 1.4).
    """

    event: CompletionEvent  # device Event, recorded after post_decode_launch publishes
    launch_buf: (
        DecodeLaunchBuffer  # post_decode_launch return: device snapshot or host staging
    )
    scheduler_output: (
        SchedulerOutput  # this step's SchedulerOutput (routing + output proc)
    )
    forward_batch: ForwardBatch | None  # for resolve-time finalize sampling
    schedule_batch: ScheduleBatch  # resolve-time snapshot (copy of the live batch)
    batch_result: (
        GenerationBatchResult  # carries logits_output (device of next_token_ids)
    )


class ModelRunner(Generic[RequestDataInput]):
    """Base AR model runner.

    Subclasses provide phase-specific behavior:
      - prefill hooks for extend/prompt processing
      - decode hooks for single-step autoregressive decode processing
    """

    def __init__(
        self,
        tp_worker: ModelWorker | MlxTpModelWorker,
        output_processor: SGLangOutputProcessor,
    ) -> None:
        self.tp_worker = tp_worker
        self.output_processor = output_processor
        self.device = current_platform.get_device(tp_worker.gpu_id)
        self.model = tp_worker.model_runner.model
        self.execution_bridge: SGLangExecutionBridge | None = None

        # Async decode (one-step lookahead). Inert unless ``_async_enabled`` is set.
        self.async_enabled: bool = False
        self.staging_slot: int = 0
        self.host_staging_buffers: list[torch.Tensor] = []
        # Observability: how often resolve found the launched step's event
        # already done (no blocking) vs had to block on synchronize(). This
        # counts whether the launched step's GPU work was published in time; it
        # does NOT measure host-D2H overlap (only host-staging runners like Higgs
        # overlap a host copy; the device-snapshot path does not).
        self.async_query_hit: int = 0
        self.async_query_miss: int = 0
        self.token_id_host_bufs: list[torch.Tensor] | None = None
        self.token_id_host_slot: int = 0
        self.suppress_tensor_cache: dict[
            tuple[tuple[int, ...], int, str], torch.Tensor | None
        ] = {}

    def stage_token_ids(self, result: GenerationBatchResult, ids: torch.Tensor) -> None:
        # Note (wenyao): pinned host copy staged once at sample time so downstream
        # .tolist() never triggers a blocking pageable D2H; next_token_ids stays device-side
        if not (isinstance(ids, torch.Tensor) and ids.is_cuda):
            result._host_token_ids = ids  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
            result._host_token_ids_event = None  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
            return
        else:
            pass
        n = ids.shape[0]
        buf = self.next_token_id_host_buf(ids, n)
        buf[:n].copy_(ids[:n], non_blocking=True)
        event = torch.cuda.Event()
        event.record()
        result._host_token_ids = buf[
            :n
        ]  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        result._host_token_ids_event = event  # noqa: leading-underscore  # upstream spelling, or the public name is already taken

    def next_token_id_host_buf(self, like: torch.Tensor, n: int) -> torch.Tensor:
        # Note (wenyao): two buffers ping-ponged so a step's host read never races
        # the next step's async copy
        return self.pinned_pingpong(
            "token_id_host_bufs",
            "token_id_host_slot",
            (n,),
            like.dtype,
            realloc_on_grow=True,
        )

    def pinned_pingpong(
        self,
        bufs_attr: str,
        slot_attr: str,
        shape: tuple[int, ...] | torch.Size,
        dtype: torch.dtype,
        *,
        realloc_on_grow: bool,
    ) -> torch.Tensor:
        """Return one of two pinned host buffers, alternating slot each call.

        ``realloc_on_grow`` reallocates (and resets the slot) when the request
        outgrows the buffer or changes dtype; otherwise the pair is allocated
        once on first use with the given fixed shape.
        """
        bufs = getattr(self, bufs_attr)
        need_alloc = not bufs
        if realloc_on_grow and bufs:
            need_alloc = (
                bufs[0].shape[0] < shape[0]
                or bufs[0].shape[1:] != tuple(shape[1:])
                or bufs[0].dtype != dtype
            )
        else:
            pass
        if need_alloc:
            bufs = [
                torch.empty(shape, dtype=dtype, device="cpu", pin_memory=True)
                for _ in range(2)
            ]
            setattr(self, bufs_attr, bufs)
            setattr(self, slot_attr, 0)
        else:
            pass
        slot = getattr(self, slot_attr)
        buf = bufs[slot]
        setattr(self, slot_attr, slot ^ 1)
        return buf

    def resolve_host_token_ids(
        self, result: GenerationBatchResult
    ) -> torch.Tensor | None:
        event = getattr(
            result, "_host_token_ids_event", None
        )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        if event is not None:
            event.synchronize()
            result._host_token_ids_event = None  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
        else:
            pass
        return getattr(
            result, "_host_token_ids", None
        )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken

    def bind_execution_bridge(self, bridge: SGLangExecutionBridge) -> None:
        """Bind the scheduler-owned SGLang execution-contract adapter."""
        self.execution_bridge = bridge

    def execution_context(
        self,
        schedule_batch: ScheduleBatch,
        *,
        isolate_sampling: bool = False,
    ) -> AbstractContextManager[None]:
        if schedule_batch.forward_mode.is_extend():
            self.restore_output_penalty_history(schedule_batch)
        else:
            pass
        return self.execution_bridge.forward_context(
            schedule_batch,
            isolate_sampling=isolate_sampling,
        )

    @staticmethod
    def restore_output_penalty_history(schedule_batch: ScheduleBatch) -> None:
        """Re-seed retained output history into the prepared penalizers."""
        sampling_info = schedule_batch.sampling_info
        if sampling_info.penalizer_orchestrator is None:
            return
        else:
            pass
        from sglang.srt.sampling.penaltylib import (
            BatchedFrequencyPenalizer,
            BatchedPresencePenalizer,
            BatchedRepetitionPenalizer,
        )

        orchestrator = sampling_info.penalizer_orchestrator
        prepared = []
        for cls, state_name, param_name in (
            (
                BatchedRepetitionPenalizer,
                "cumulated_repetition_penalties",
                "repetition_penalty",
            ),
            (
                BatchedFrequencyPenalizer,
                "cumulated_frequency_penalties",
                "frequency_penalty",
            ),
            (
                BatchedPresencePenalizer,
                "cumulated_presence_penalties",
                "presence_penalty",
            ),
        ):
            penalizer = orchestrator.penalizers.get(cls)
            if penalizer is not None and penalizer.is_prepared():
                prepared.append((getattr(penalizer, state_name), param_name))
            else:
                pass
        if not prepared:
            return
        else:
            pass

        rows, token_ids, counts = [], [], []
        for row, req in enumerate(schedule_batch.reqs):
            # Note: (Junnan Li) prepare_for_extend clears req.is_retracted, so
            # the retained output_ids are the only record of emitted tokens.
            retained = Counter(
                token_id
                for token_id in req.output_ids
                if 0 <= token_id < orchestrator.vocab_size
            )
            rows.extend([row] * len(retained))
            token_ids.extend(retained)
            counts.extend(retained.values())
        if not rows:
            return
        else:
            pass

        device = prepared[0][0].device
        row_indices = torch.tensor(rows, dtype=torch.long, device=device)
        token_indices = torch.tensor(token_ids, dtype=torch.long, device=device)
        for state, param_name in prepared:
            values = [
                float(getattr(schedule_batch.reqs[row].sampling_params, param_name))
                * (count if param_name == "frequency_penalty" else 1)
                for row, count in zip(rows, counts)
            ]
            state[row_indices, token_indices] = torch.tensor(
                values, dtype=state.dtype, device=device
            )

    def next_host_staging(
        self, shape: tuple[int, ...] | torch.Size, dtype: torch.dtype
    ) -> torch.Tensor:
        """Return a pinned host staging buffer covering ``shape``/``dtype``,
        ping-ponging between two buffers on each call. Runners that stage the
        collect to host use this: Higgs passes its fixed CG staging shape, the
        base plain-LM launch passes the step's ``(batch_size,)`` ids shape.
        Device-snapshot runners (MOSS-TTS-Local) never do.

        Two buffers are required: resolve(N) reads one on the host while
        launch(N+1)'s async host copy writes the other. That CPU-read vs
        GPU-write overlap is not protected by single-stream ordering.
        Buffers are allocated lazily on first use and replaced when the
        requested dim 0 outgrows them (or trailing dims / dtype change); a
        resolve still holding the previous buffer keeps it alive, so
        replacement cannot alias an in-flight snapshot.
        """
        return self.pinned_pingpong(
            "host_staging_buffers",
            "staging_slot",
            tuple(shape),
            dtype,
            realloc_on_grow=True,
        )

    def execute(self, scheduler_output: SchedulerOutput) -> ModelRunnerOutput:
        """Full synchronous pipeline: build → prepare → forward → post →
        sample → output.

        Used when async decode is disabled. Behavior is byte-identical to the
        pre-async implementation: it is a pure extraction over the same shared
        sub-steps (``_build_forward_batch`` / ``_prepare_and_forward`` /
        ``_finalize``) that ``execute_launch`` + ``execute_resolve`` also use,
        in the same order. Async decode splits this at the post-decode boundary.
        """
        schedule_batch = scheduler_output.batch_data
        if schedule_batch is None:
            return ModelRunnerOutput(outputs={}, req_ids=[], req_id_to_index={})
        else:
            pass
        with self.execution_context(schedule_batch, isolate_sampling=True):
            built = self.build_forward_batch(scheduler_output)
            if built is None:
                return ModelRunnerOutput(outputs={}, req_ids=[], req_id_to_index={})
            else:
                pass
            forward_batch, schedule_batch, is_prefill = built
            batch_result = self.prepare_and_forward(
                forward_batch, schedule_batch, scheduler_output.requests, is_prefill
            )
            if is_prefill:
                self.post_prefill(
                    batch_result,
                    forward_batch,
                    schedule_batch,
                    scheduler_output.requests,
                )
            else:
                self.post_decode(
                    batch_result,
                    forward_batch,
                    schedule_batch,
                    scheduler_output.requests,
                )
            self.ensure_next_token_ids(
                batch_result,
                forward_batch,
                schedule_batch,
                scheduler_output,
            )
            self.publish_next_tokens(
                batch_result,
                forward_batch,
                schedule_batch,
                scheduler_output.requests,
            )
        return self.finalize(
            batch_result,
            forward_batch,
            schedule_batch,
            scheduler_output,
        )

    def execute_launch(self, scheduler_output: SchedulerOutput) -> "PendingStep | None":
        """Enqueue a decode step's forward + on-GPU sample, call
        ``post_decode_launch`` to publish a model-specific resolve payload
        (returned as launch_buf), and record a device event right after
        publication. Does NOT wait on the GPU. Decode batches only. ``launch_buf``
        is a device-side correctness snapshot (MOSS-TTS-Local) or pinned host
        staging (Higgs); only the latter overlaps a host copy with the next
        forward, and ``event.query()`` proves the launched step's GPU work is
        done, not that any host overlap happened.

        Returns the ``_PendingStep`` handle (or None if there was no batch).
        The CALLER owns the handle and passes it to ``execute_resolve`` later.
        Ownership lives with the caller (not on ``self``) because launch-first
        scheduling has two steps momentarily in flight: the just-launched step
        N and the not-yet-resolved step N-1.
        """
        schedule_batch = scheduler_output.batch_data
        if schedule_batch is None:
            return None
        else:
            pass
        with self.execution_context(schedule_batch, isolate_sampling=True):
            built = self.build_forward_batch(scheduler_output)
            if built is None:
                return None
            else:
                pass
            forward_batch, schedule_batch, is_prefill = built
            assert not is_prefill, "async lookahead launch is decode-only"
            batch_result = self.prepare_and_forward(
                forward_batch,
                schedule_batch,
                scheduler_output.requests,
                is_prefill,
                is_lookahead=True,
            )
            launch_buf = self.post_decode_launch(
                batch_result, forward_batch, scheduler_output.requests
            )
            self.ensure_next_token_ids(
                batch_result,
                forward_batch,
                schedule_batch,
                scheduler_output,
            )
            self.publish_next_tokens(
                batch_result,
                forward_batch,
                schedule_batch,
                scheduler_output.requests,
            )
            event = self.execution_bridge.record_completion()
            # Never retain the mutable live ScheduleBatch across a lookahead
            # iteration. The upstream overlap loop likewise queues batch.copy().
            resolve_batch = schedule_batch.copy()
            resolve_scheduler_output = replace(
                scheduler_output, batch_data=resolve_batch
            )
        return PendingStep(
            event=event,
            launch_buf=launch_buf,
            scheduler_output=resolve_scheduler_output,
            forward_batch=forward_batch,
            schedule_batch=resolve_batch,
            batch_result=batch_result,
        )

    def execute_resolve(
        self, pending: "PendingStep | None"
    ) -> ModelRunnerOutput | None:
        """Consume a launched decode step: wait on its event (non-blocking
        ``query()``, else ``synchronize()``), read its ``launch_buf`` (a device
        snapshot or pinned host staging) and run the per-request collect loop
        (``post_decode_resolve``), then
        finalize sampling/output. Returns that step's ``ModelRunnerOutput``,
        or None if ``pending`` is None (first iteration / after a drain).
        """
        if pending is None:
            return None
        else:
            pass
        if pending.event.query():
            self.async_query_hit += 1
        else:
            pending.event.synchronize()
            self.async_query_miss += 1
        # Skip reqs finished or retracted in a prior (lagged) step so _finalize
        # neither re-emits nor re-frees their KV (mirrors _resolve_and_process).
        skip_rids = {
            req.request_id
            for req in pending.scheduler_output.requests
            if req.data.req.finished() or self.req_is_retracted(req.data.req)
        }
        self.post_decode_resolve(
            pending.launch_buf,
            pending.batch_result,
            pending.forward_batch,
            pending.schedule_batch,
            pending.scheduler_output.requests,
        )
        return self.finalize(
            pending.batch_result,
            pending.forward_batch,
            pending.schedule_batch,
            pending.scheduler_output,
            skip_rids=skip_rids,
        )

    def build_forward_batch(
        self, scheduler_output: SchedulerOutput
    ) -> tuple[ForwardBatch | None, ScheduleBatch, bool] | None:
        """Build the ForwardBatch + capture-hidden mode. Returns
        ``(forward_batch, schedule_batch, is_prefill)``, or
        None when there is no batch to run."""
        from sglang.srt.model_executor.forward_batch_info import (
            CaptureHiddenMode,
            ForwardBatch,
        )

        if self.device.type != "cpu":
            torch.get_device_module(self.device).set_device(self.device.index or 0)
        else:
            pass

        schedule_batch = scheduler_output.batch_data
        if schedule_batch is None:
            return None
        else:
            pass

        is_prefill = bool(schedule_batch.forward_mode.is_extend())

        capture_hidden_mode = (
            self.requested_capture_hidden_mode_prefill(
                schedule_batch, scheduler_output.requests
            )
            if is_prefill
            else self.requested_capture_hidden_mode_decode(
                schedule_batch, scheduler_output.requests
            )
        )
        if capture_hidden_mode is None and self.output_processor.capture_hidden:
            capture_hidden_mode = CaptureHiddenMode.LAST
        else:
            pass

        # init_new does not read capture_hidden_mode off the batch, so pass the
        # override explicitly; None lets upstream derive it.
        forward_batch = ForwardBatch.init_new(
            schedule_batch,
            self.tp_worker.model_runner,
            capture_hidden_mode=capture_hidden_mode,
            return_hidden_states_before_norm=False,
        )
        return forward_batch, schedule_batch, is_prefill

    def prepare_and_forward(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
        is_prefill: bool,
        *,
        is_lookahead: bool = False,
    ) -> GenerationBatchResult:
        """Prepare hook → standard forward (if not custom) → sample-before-post
        block. Returns ``batch_result``."""
        try:
            if is_prefill:
                self.before_prefill(forward_batch, schedule_batch, requests)
                batch_result = self.custom_prefill_forward(
                    forward_batch, schedule_batch, requests
                )
            else:
                self.before_decode(
                    forward_batch,
                    schedule_batch,
                    requests,
                    is_lookahead=is_lookahead,
                )
                batch_result = self.custom_decode_forward(
                    forward_batch, schedule_batch, requests
                )
            if batch_result is None:
                batch_result = self.tp_worker.forward_batch_generation(forward_batch)
            else:
                pass

            if (
                not schedule_batch.is_prefill_only
                and batch_result.next_token_ids is None
                and (
                    self.sample_before_post_prefill(
                        forward_batch, schedule_batch, requests
                    )
                    if is_prefill
                    else self.sample_before_post_decode(
                        forward_batch, schedule_batch, requests
                    )
                )
            ):
                batch_result.next_token_ids = self.sample_next_token_ids(
                    batch_result.logits_output,
                    forward_batch,
                    schedule_batch,
                    requests,
                )
            else:
                pass
            return batch_result
        finally:
            if is_prefill:
                clear_omni_prefill_inputs(forward_batch)
                self.cleanup_prefill(forward_batch, schedule_batch, requests)
            else:
                pass

    def finalize_skip_rids(self, scheduler_output: SchedulerOutput) -> set[str]:
        """Request ids whose ``generation_steps`` must NOT advance this step.

        Default empty. A model overrides this when a batch contains rows that
        are sampled but must not count as a generated step — e.g. non-final
        chunked-prefill rows, whose spurious step would shift the final chunk's
        sampling position off the no-chunk path. Unioned into ``skip_rids``
        inside ``_finalize`` so it covers the sync, async-resolve, and
        prefill-only paths alike. Additive and behaviour-neutral for any model
        that does not override it.
        """
        return set()

    def on_generation_step_advanced(
        self, sched_req: SchedulerRequest, generation_steps: int
    ) -> None:
        """Hook after ``generation_steps`` is committed on request data."""
        return None

    def on_generation_steps_advanced(
        self,
        advanced_steps: list[tuple[SchedulerRequest, int]],
        forward_batch: ForwardBatch | None,
    ) -> None:
        """Batch hook after ``generation_steps`` are committed on request data."""
        del forward_batch
        for sched_req, generation_steps in advanced_steps:
            self.on_generation_step_advanced(sched_req, generation_steps)

    def finalize(
        self,
        batch_result: GenerationBatchResult,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        scheduler_output: SchedulerOutput,
        skip_rids: set[str] | None = None,
    ) -> ModelRunnerOutput:
        """Output extraction + per-request bookkeeping. Shared tail of both
        the sync and async paths; callers materialize reporting tokens via
        _ensure_next_token_ids before the launch is considered complete. The
        next-forward GPU token rail is published through SGLangExecutionBridge;
        async resolve must never stamp its lagged result onto a live batch."""
        host_token_ids = self.resolve_host_token_ids(batch_result)
        if host_token_ids is None:
            outputs = self.output_processor.process(batch_result, scheduler_output)
        else:
            outputs = self.output_processor.process(
                batch_result, scheduler_output, host_token_ids=host_token_ids
            )
        self.post_process_outputs(batch_result, scheduler_output, outputs)
        skip_rids = (skip_rids or set()) | self.finalize_skip_rids(scheduler_output)
        advanced_steps = []
        for sched_req in scheduler_output.requests:
            if sched_req.request_id in skip_rids:
                continue
            else:
                pass
            data = sched_req.data
            data.generation_steps = int(data.generation_steps) + 1
            advanced_steps.append((sched_req, data.generation_steps))
            req_output = outputs[sched_req.request_id]
            extra = req_output.extra
            if isinstance(extra, dict) and extra:
                data.extra_model_outputs.update(extra)
            else:
                pass
        if advanced_steps:
            self.on_generation_steps_advanced(advanced_steps, forward_batch)
        else:
            pass
        req_ids = [req.request_id for req in scheduler_output.requests]
        req_id_to_index = {req_id: idx for idx, req_id in enumerate(req_ids)}

        return ModelRunnerOutput(
            outputs=outputs,
            req_ids=req_ids,
            req_id_to_index=req_id_to_index,
            can_run_cuda_graph=bool(batch_result.can_run_cuda_graph),
            next_token_ids=batch_result.next_token_ids,
            host_token_ids=host_token_ids,
        )

    def ensure_next_token_ids(
        self,
        batch_result: GenerationBatchResult,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        scheduler_output: SchedulerOutput,
    ) -> None:
        """Materialize this step's reporting tokens while still on its stream."""
        if schedule_batch.is_prefill_only:
            if batch_result.next_token_ids is None:
                batch_result.next_token_ids = torch.zeros(
                    len(schedule_batch.seq_lens),
                    dtype=torch.long,
                    device=schedule_batch.input_ids.device,
                )
            else:
                pass
        elif batch_result.next_token_ids is None:
            batch_result.next_token_ids = self.sample_next_token_ids(
                batch_result.logits_output,
                forward_batch,
                schedule_batch,
                scheduler_output.requests,
            )
        else:
            pass

    def next_input_token_ids(
        self,
        result: GenerationBatchResult,
        forward_batch: ForwardBatch | None,
        requests: list[SchedulerRequest],
    ) -> torch.Tensor | None:
        """Return the GPU token rail consumed by the next forward."""
        del forward_batch, requests
        return (
            result.next_token_ids
            if isinstance(result.next_token_ids, torch.Tensor)
            else None
        )

    def publish_next_tokens(
        self,
        result: GenerationBatchResult,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> None:
        if schedule_batch.is_prefill_only:
            return
        else:
            pass
        self.execution_bridge.publish_next_tokens(
            schedule_batch,
            self.next_input_token_ids(result, forward_batch, requests),
        )

    # ------------------------------------------------------------------
    # Hooks — override in subclasses
    # ------------------------------------------------------------------

    def before_prefill(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> None:
        """Mutate state before the standard or custom prefill forward."""

    def cleanup_prefill(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> None:
        """Release one-forward prefill state on success or failure."""

    def before_decode(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
        *,
        is_lookahead: bool = False,
    ) -> None:
        """Mutate state before the standard or custom decode forward."""
        del is_lookahead

    def custom_prefill_forward(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> GenerationBatchResult | None:
        """Run a model-specific prefill forward.

        Return a batch result when the subclass owns the forward path for this
        batch, or None to use the standard tp_worker forward path.
        """
        return None

    def custom_decode_forward(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> GenerationBatchResult | None:
        """Run a model-specific decode forward.

        Return a batch result when the subclass owns the forward path for this
        batch, or None to use the standard tp_worker forward path.
        """
        return None

    def post_prefill(
        self,
        result: GenerationBatchResult,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> None:
        """Called after prefill forward."""

    def post_decode(
        self,
        result: GenerationBatchResult,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> None:
        """Called after decode forward."""

    def lookahead_eligible(self, batch: ScheduleBatch) -> bool:
        """Whether this batch may use one-step async-decode lookahead.

        The default launch samples one step before resolve appends the previous
        token to ``req.output_ids`` / the sglang penalizer state, so any sampling
        term scored by output history (repetition / frequency / presence penalty,
        ``min_new_tokens``, custom logit processors) would read a one-token-stale
        view and diverge from sync — gate those batches to sync. Over-gating only
        costs throughput, under-gating is a silent divergence. Runners override
        for other fallbacks.
        """

        def _history_free(req: Req) -> bool:
            sp = req.sampling_params
            return (
                sp.repetition_penalty == 1.0
                and sp.frequency_penalty == 0.0
                and sp.presence_penalty == 0.0
                and sp.min_new_tokens == 0
                and req.custom_logit_processor is None
            )

        return all(_history_free(req) for req in batch.reqs)

    def post_process_outputs(
        self,
        result: GenerationBatchResult,
        scheduler_output: SchedulerOutput,
        outputs: dict[str, RequestOutput],
    ) -> None:
        """Called after output tokens are materialized into RequestOutput."""

    def on_request_finished(self, request_id: str, req_data: RequestDataInput) -> None:
        """Drain per-request state on any non-abort finish.

        Called from ``OmniScheduler.stream_output`` before the terminal payload
        is enqueued on the same outbox, so runners that buffer stream chunks
        across decode steps can flush them ahead of stream completion.
        """

    def post_decode_launch(
        self,
        result: GenerationBatchResult,
        forward_batch: ForwardBatch | None,
        requests: list[SchedulerRequest],
    ) -> DecodeLaunchBuffer:
        """Async-decode GPU half of ``post_decode``: sample now, publish
        ``result.next_token_ids``, and return the resolve payload (``launch_buf``);
        the caller records a device event right after.

        Default (plain-LM): sample via ``_sample_next_token_ids`` and snapshot the
        ids into a pinned ping-pong host buffer (required — the sampler output can
        alias step-reused buffers the next launch overwrites). Codec runners whose
        collect is more than next_token_ids override this with ``post_decode_resolve``.
        """
        if not requests:
            return None
        else:
            pass
        if result.next_token_ids is None:
            result.next_token_ids = self.sample_next_token_ids(
                result.logits_output, forward_batch, None, requests
            )
        else:
            pass
        n = len(requests)
        ids = result.next_token_ids
        host_buf = self.next_host_staging((n,), ids.dtype)
        host_buf[:n].copy_(ids[:n], non_blocking=True)
        return host_buf

    def post_decode_resolve(
        self,
        launch_buf: DecodeLaunchBuffer,
        result: GenerationBatchResult,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> None:
        """Async-decode host half of ``post_decode``: read ``launch_buf`` and set
        ``result.next_token_ids``. Default (plain-LM): point it at the pinned host
        snapshot — the caller already waited on the launch event, so ``_finalize``
        reads it without a GPU sync.
        """
        del forward_batch, schedule_batch
        if launch_buf is None or not requests:
            return
        else:
            pass
        result.next_token_ids = launch_buf[: len(requests)]

    def sample_before_post_prefill(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> bool:
        return False

    def sample_before_post_decode(
        self,
        forward_batch: ForwardBatch | None,
        schedule_batch: ScheduleBatch,
        requests: list[SchedulerRequest],
    ) -> bool:
        return False

    def requested_capture_hidden_mode_prefill(
        self, schedule_batch: ScheduleBatch, requests: list[SchedulerRequest]
    ) -> CaptureHiddenMode | None:
        return None

    def requested_capture_hidden_mode_decode(
        self, schedule_batch: ScheduleBatch, requests: list[SchedulerRequest]
    ) -> CaptureHiddenMode | None:
        return None

    # ------------------------------------------------------------------
    # Shared logit processing
    # ------------------------------------------------------------------

    def sample_next_token_ids(
        self,
        logits_output: LogitsProcessorOutput,
        forward_batch: ForwardBatch,
        schedule_batch: ScheduleBatch | None,
        requests: list[SchedulerRequest],
    ) -> torch.Tensor:
        self.apply_codec_suppress_tokens(logits_output, requests)
        self.process_sampling_logits(logits_output, requests)
        self.install_sampling_seeds(forward_batch, requests)
        wants_rollout_logprob = any(sr.data.return_logprob for sr in requests)
        if wants_rollout_logprob:
            self.enable_sampler_logprobs(forward_batch, len(requests))
        else:
            pass
        next_token_ids = self.tp_worker.model_runner.sample(
            logits_output, forward_batch
        )
        if wants_rollout_logprob:
            try:
                next_token_logprobs = logits_output.next_token_logprobs
            except AttributeError as exc:
                raise RuntimeError(
                    "Sampler did not populate next_token_logprobs when "
                    "return_logprob is enabled"
                ) from exc
            if next_token_logprobs is None:
                raise RuntimeError(
                    "Sampler did not populate next_token_logprobs when "
                    "return_logprob is enabled"
                )
            else:
                pass
            self.record_rollout_logprobs(
                next_token_logprobs,
                next_token_ids,
                requests,
            )
        else:
            pass
        return next_token_ids

    def process_sampling_logits(
        self, logits_output: LogitsProcessorOutput, requests: list[SchedulerRequest]
    ) -> None:
        pass

    def install_sampling_seeds(
        self, forward_batch: ForwardBatch, requests: list[SchedulerRequest]
    ) -> None:
        """Install per-row ``seed``s onto ``sampling_info`` so SGLang routes to
        ``multinomial_with_seed``. No-op when no request set a seed, or when a
        subclass already installed its own (e.g. Qwen3-TTS).

        Runs once per decode step. User-provided seeds are resolved once and
        cached back onto ``sampling_params.sampling_seed``. In a mixed
        seeded/unseeded batch the SGLang sampler is batch-wide, so unseeded rows
        receive a request-id-derived fallback seed instead of a rank-local random
        seed; this keeps TP ranks in sync without mutating the public request seed.
        """
        sampling_info = forward_batch.sampling_info
        if sampling_info.sampling_seed is not None:
            self.validate_seeded_sampling_supported(sampling_info)
            return
        else:
            pass
        sampling_params = [sr.data.req.sampling_params for sr in requests]
        if all(sp.sampling_seed is None for sp in sampling_params):
            return
        else:
            pass
        self.validate_seeded_sampling_supported(sampling_info)
        row_seeds: list[int] = []
        for row_idx, (sp, request) in enumerate(zip(sampling_params, requests)):
            seed = sp.sampling_seed
            if seed is None:
                seed = rank_shared_unseeded_sampling_seed(request, row_idx)
            elif not (0 <= seed <= SAMPLING_SEED_MASK):
                seed = resolve_row_seed(seed)  # mask and cache user seed
                sp.sampling_seed = seed
            else:
                pass
            row_seeds.append(seed)
        sampling_info.sampling_seed = torch.tensor(
            row_seeds, dtype=torch.long, device=sampling_info.device
        )

    @staticmethod
    def validate_seeded_sampling_supported(sampling_info: SamplingBatchInfo) -> None:
        if sampling_info.need_min_p_sampling:
            raise ValueError(
                "SGLang seeded sampling does not support min_p yet; set min_p=0 "
                "or omit request seed"
            )
        else:
            pass
        need_top_p_sampling = sampling_info.need_top_p_sampling
        need_top_k_sampling = sampling_info.need_top_k_sampling
        if not (need_top_p_sampling or need_top_k_sampling):
            return
        else:
            pass
        if current_sglang_sampling_backend() == "flashinfer":
            raise ValueError(
                "SGLang flashinfer sampling backend does not support request seed "
                "with top_p/top_k filtering; configure sampling_backend='pytorch' "
                "or avoid top_p/top_k with seed"
            )
        else:
            pass

    @staticmethod
    def enable_sampler_logprobs(forward_batch: ForwardBatch, batch_size: int) -> None:
        forward_batch.return_logprob = True
        if forward_batch.top_logprobs_nums is None:
            forward_batch.top_logprobs_nums = [0] * batch_size
        else:
            pass
        if forward_batch.token_ids_logprobs is None:
            forward_batch.token_ids_logprobs = [None] * batch_size
        else:
            pass

    def record_rollout_logprobs(
        self, next_token_logprobs, next_token_ids, requests: list[SchedulerRequest]
    ) -> None:
        """Append each rollout request's sampled-token logprob (one per step)."""
        logprobs = sampled_logprobs_to_list(next_token_logprobs)
        if logprobs is None:
            try:
                shape = next_token_logprobs.shape
            except AttributeError:
                shape = None
            raise RuntimeError(
                "Failed to convert sampler next_token_logprobs "
                f"type={type(next_token_logprobs).__name__} shape={shape}"
            )
        else:
            pass
        if next_token_ids is None:
            raise RuntimeError("Sampler did not return next_token_ids")
        else:
            pass
        try:
            token_id_values = next_token_ids.tolist()
        except AttributeError:
            token_id_values = next_token_ids
        token_ids = [int(t) for t in token_id_values]
        if len(logprobs) != len(token_ids) or len(logprobs) != len(requests):
            raise RuntimeError(
                "rollout logprob batch-size mismatch: "
                f"logprobs={len(logprobs)} token_ids={len(token_ids)} "
                f"requests={len(requests)}"
            )
        else:
            pass
        for row_idx, sched_req in enumerate(requests):
            data = sched_req.data
            if data.return_logprob:
                data.output_token_logprobs.append(
                    [logprobs[row_idx], token_ids[row_idx]]
                )
            else:
                pass

    @staticmethod
    def req_is_retracted(req: Req) -> bool:
        return bool(req.is_retracted)

    def apply_codec_suppress_tokens(
        self, logits_output: LogitsProcessorOutput, requests: list[SchedulerRequest]
    ) -> None:
        logits = logits_output.next_token_logits
        if logits is None or logits.ndim != 2:
            return
        else:
            pass
        vocab = logits.shape[1]
        device = logits.device
        # Note: (Jiaxin Deng) the suppress set comes from model config, so keying
        # by content collapses the whole fleet onto one device tensor; the key
        # itself is derived once per request because the builder hands out a
        # fresh list object each time.
        cache = getattr(self, "suppress_tensor_cache", None)
        if cache is None:
            cache = {}
            self.suppress_tensor_cache = cache
        else:
            pass
        row_groups: dict[
            tuple[tuple[int, ...], int, str], tuple[torch.Tensor, list[int]]
        ] = {}
        for row_idx, sched_req in enumerate(requests):
            data = sched_req.data
            suppress_tokens = data.suppress_tokens
            if not suppress_tokens:
                req = data.req
                try:
                    suppress_tokens = (
                        req._codec_suppress_tokens
                    )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
                except AttributeError:
                    suppress_tokens = None
            else:
                pass
            if not suppress_tokens:
                continue
            else:
                pass
            content = getattr(
                data, "_suppress_content", None
            )  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
            if content is None:
                content = tuple(int(t) for t in suppress_tokens)
                data._suppress_content = content  # noqa: leading-underscore  # upstream spelling, or the public name is already taken
            else:
                pass
            key = (content, vocab, str(device))
            toks_t = cache.get(key)
            if key not in cache:
                toks = [t for t in content if 0 <= t < vocab]
                toks_t = (
                    torch.tensor(toks, dtype=torch.long, device=device)
                    if toks
                    else None
                )
                cache[key] = toks_t
            else:
                pass
            if toks_t is None:
                continue
            else:
                pass
            group = row_groups.get(key)
            if group is None:
                row_groups[key] = (toks_t, [row_idx])
            else:
                group[1].append(row_idx)
        for toks_t, rows in row_groups.values():
            if len(rows) == logits.shape[0]:
                logits[:, toks_t] = float("-inf")
            else:
                rows_t = torch.tensor(rows, dtype=torch.long, device=device)
                logits[rows_t[:, None], toks_t[None, :]] = float("-inf")
