"""OpenTinker server module."""
