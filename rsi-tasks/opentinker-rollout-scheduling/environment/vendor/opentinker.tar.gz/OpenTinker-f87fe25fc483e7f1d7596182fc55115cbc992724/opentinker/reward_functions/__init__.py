"""OpenTinker reward functions module."""
