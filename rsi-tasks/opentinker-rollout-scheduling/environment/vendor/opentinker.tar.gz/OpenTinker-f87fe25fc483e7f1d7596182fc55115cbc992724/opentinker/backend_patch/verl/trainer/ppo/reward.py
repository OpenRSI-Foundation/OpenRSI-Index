# Copyright 2025 Individual Contributor: Thibaut Barroyer
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
original file: verl/trainer/ppo/reward.py
"""

import importlib.util
import inspect
import multiprocessing
import os
import sys
import warnings
from functools import partial
from typing import Any, Optional

import ray
import torch
from omegaconf import DictConfig

from verl import DataProto
from verl.utils.reward_score import default_compute_score
from verl.utils.transferqueue_utils import tqbridge
from verl.workers.reward_manager import get_reward_manager_cls
from verl.workers.reward_manager.abstract import AbstractRewardManager, RawRewardFn


def _call_with_kwargs(raw_fn, extra_kwargs, *args, **kwargs):
    """Calls `raw_fn` by merging `extra_kwargs` into call-time `kwargs`, with `extra_kwargs` taking precedence.

    This function is used to merge additional keyword arguments with the original function's arguments.
    """
    merged_kwargs = {**kwargs, **extra_kwargs}
    return raw_fn(*args, **merged_kwargs)


async def _call_with_kwargs_async(raw_fn, extra_kwargs, *args, **kwargs):
    """Calls `raw_fn` by merging `extra_kwargs` into call-time `kwargs`, with `extra_kwargs` taking precedence.

    This function is used to merge additional keyword arguments with the original function's arguments.
    """
    merged_kwargs = {**kwargs, **extra_kwargs}
    return await raw_fn(*args, **merged_kwargs)


def get_custom_reward_fn(config: DictConfig) -> Optional[RawRewardFn]:
    """Load and return a custom reward function from external file or remote API.

    Dynamically imports a reward function from a specified file path and wraps
    it with additional keyword arguments from the configuration, or creates a
    remote API caller for HTTP-based reward functions.

    Args:
        config (dict): Configuration dictionary containing custom_reward_function
                      settings with 'path', 'name', 'reward_kwargs' for file-based,
                      or 'type', 'remote_endpoint', 'remote_api_key' for remote.

    Returns:
        callable or None: Wrapped reward function with merged kwargs, or None
                         if no custom reward function is configured.

    Raises:
        FileNotFoundError: If the specified reward function file doesn't exist.
        RuntimeError: If there's an error loading the module from file.
        AttributeError: If the specified function name isn't found in the module.
    """

    reward_fn_config = config.get("custom_reward_function") or {}

    # Check if this is a typed configuration (new format)
    reward_type = reward_fn_config.get("type")

    if reward_type == "remote":
        # Remote API type - call external HTTP endpoint
        remote_endpoint = reward_fn_config.get("remote_endpoint")
        if not remote_endpoint:
            raise ValueError("remote_endpoint is required for type='remote'")

        remote_api_key = reward_fn_config.get("remote_api_key")

        # Create remote API caller based on recipe/opentinker/reward_function.py pattern
        # NOTE: This function is called PER SAMPLE by NaiveRewardManager (default)
        # For batch processing, use BatchRewardManager with a batch-style reward function
        def remote_reward_fn(
            data_source, solution_str, ground_truth, extra_info, **kwargs
        ):
            """
            Call remote reward API endpoint for a single example.

            This function follows the signature expected by NaiveRewardManager:
            - Single data_source (str), not data_sources (list)
            - Single solution_str (str), not solution_strs (list)
            - Single ground_truth (str), not ground_truths (list)
            - Single extra_info (dict), not extra_infos (list)
            """
            import requests
            from time import sleep

            MAX_RETRIES = 3
            BASE_DELAY = 2

            for attempt in range(MAX_RETRIES):
                try:
                    headers = {}
                    if remote_api_key:
                        headers["Authorization"] = f"Bearer {remote_api_key}"

                    data = {
                        "data_source": data_source,
                        "solution_str": solution_str,
                        "ground_truth": ground_truth,
                        "extra_info": extra_info,
                        # **kwargs
                    }

                    response = requests.post(
                        f"{remote_endpoint}/compute_reward",
                        json=data,
                        headers=headers,
                        timeout=300,
                    )
                    response.raise_for_status()
                    return response.json()["reward"]

                except Exception as e:
                    if attempt < MAX_RETRIES - 1:
                        delay = BASE_DELAY * (2**attempt)
                        print(
                            f"Remote reward API error (attempt {attempt + 1}/{MAX_RETRIES}): {e}"
                        )
                        print(f"Retrying in {delay} seconds...")
                        sleep(delay)
                    else:
                        print(
                            f"Failed to get remote reward after {MAX_RETRIES} attempts: {e}"
                        )
                        return 0.0  # Return 0 on failure

            # Should not reach here, but return 0.0 as fallback
            return 0.0

        print(f"Using remote reward function API: {remote_endpoint}")
        return remote_reward_fn

    # File-based type (config or code) - original implementation
    file_path = reward_fn_config.get("config_path") or reward_fn_config.get("path")
    if not file_path:
        return None

    function_name = reward_fn_config.get("config_name") or reward_fn_config.get("name")
    assert function_name is not None

    module = sys.modules.get("custom_module", None)
    if module is None:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Reward function file '{file_path}' not found.")

        spec = importlib.util.spec_from_file_location("custom_module", file_path)
        assert spec is not None
        module = importlib.util.module_from_spec(spec)
        try:
            sys.modules["custom_module"] = module
            assert spec.loader is not None
            spec.loader.exec_module(module)
        except Exception as e:
            raise RuntimeError(f"Error loading module from '{file_path}': {e}") from e

    if not hasattr(module, function_name):
        raise AttributeError(
            f"Reward function '{function_name}' not found in '{module.__file__}'."
        )

    print(
        f"using customized reward function '{function_name}' from '{module.__file__}'"
    )
    raw_fn = getattr(module, function_name)

    reward_kwargs = dict(
        reward_fn_config.get("reward_kwargs", {})
        or reward_fn_config.get("config_kwargs", {})
    )

    if not inspect.iscoroutinefunction(raw_fn):
        return partial(_call_with_kwargs, raw_fn, reward_kwargs)
    else:
        return partial(_call_with_kwargs_async, raw_fn, reward_kwargs)


def load_reward_manager(
    config: DictConfig, tokenizer: Any, num_examine: int, **reward_kwargs: Any
) -> AbstractRewardManager:
    """
    Load and initialize a reward manager based on the configuration.

    Args:
        config: PPO trainer configuration object containing reward_model fields.
        tokenizer: Tokenizer object used for processing text.
        num_examine: Number of samples to examine.
        **reward_kwargs: Additional keyword arguments for the reward manager.

    Returns:
        An instance of the specified reward manager class.
    """

    # Try to get a custom reward function based on the configuration
    # user defined reward manager can be registered in custom_reward_fn
    compute_score = get_custom_reward_fn(config)
    final_compute_score = compute_score

    # The list of pre-defined reward managers are defined in `verl/workers/reward_manager/`:
    # naive: NaiveRewardManager
    # prime: PrimeRewardManager
    # batch: BatchRewardManager
    # dapo: DAPORewardManager
    # Note(haibin.lin): For custom reward managers, please make sure they are imported and
    # registered via `verl.workers.reward_manager.register`
    # By default reward_manager is set to naive (NaiveRewardManager)
    reward_manager_name = config.reward_model.get("reward_manager", "naive")
    reward_manager_cls = get_reward_manager_cls(reward_manager_name)

    if compute_score is None:
        sandbox_config = config.reward_model.get("sandbox_fusion")
        sandbox_url = sandbox_config.get("url") if sandbox_config else None
        memory_limit_mb = (
            sandbox_config.get("memory_limit_mb", 1024) if sandbox_config else 1024
        )
        if sandbox_url:
            sandbox_manager = multiprocessing.Manager()
            # Create a semaphore to control concurrent access to the sandbox
            _concurrent_semaphore = sandbox_manager.Semaphore(
                sandbox_config.get("max_concurrent", 64)
            )
            final_compute_score = partial(
                default_compute_score,
                sandbox_fusion_url=sandbox_url,
                concurrent_semaphore=_concurrent_semaphore,
                memory_limit_mb=memory_limit_mb,
            )
        else:
            final_compute_score = default_compute_score

    # Instantiate and return the reward manager with the specified parameters
    return reward_manager_cls(
        tokenizer=tokenizer,
        num_examine=num_examine,
        compute_score=final_compute_score,
        reward_fn_key=config.data.reward_fn_key,
        **reward_kwargs,
    )


@tqbridge(put_data=False)
def compute_reward(
    data: DataProto, reward_fn: AbstractRewardManager
) -> tuple[torch.Tensor, dict[str, Any]]:
    """
    Compute reward for a batch of data.
    Args:
        data: DataProto object containing the input data.
        reward_fn: Reward function to compute the reward.
    Returns:
        Tuple of reward tensor and extra info dictionary.
    """
    try:
        reward_result = reward_fn(data, return_dict=True)
        reward_tensor = reward_result["reward_tensor"]
        reward_extra_infos_dict = reward_result.get("reward_extra_info", {})
    except Exception as e:
        print(f"Error in reward_fn: {e}")
        reward_tensor = reward_fn(data)
        reward_extra_infos_dict = {}

    return reward_tensor, reward_extra_infos_dict


@ray.remote(num_cpus=1)
def compute_reward_async(data: DataProto, config=None, tokenizer=None, reward_fn=None):
    """
    Load the reward manager and compute the reward for a batch of data.
    This is meant to be run in a separate Ray worker.
    """
    if reward_fn is None:
        assert (
            config is not None and tokenizer is not None
        ), "config and tokenizer must not be None when reward_fn is None"

        warnings.warn(
            "using config and tokenizer with compute_reward_async is deprecated",
            stacklevel=2,
        )
        reward_fn = load_reward_manager(
            config,
            tokenizer,
            num_examine=0,
            **config.reward_model.get("reward_kwargs", {}),
        )

    return compute_reward(data, reward_fn)
